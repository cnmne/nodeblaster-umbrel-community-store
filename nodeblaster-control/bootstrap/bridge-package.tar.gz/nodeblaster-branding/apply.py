#!/usr/bin/env python3
from __future__ import annotations

import datetime as _dt
import argparse
import fcntl
import json
import os
import re
import shutil
import subprocess
import urllib.request
from pathlib import Path


HOSTNAME = "nodeblaster"
DATA_DIR = Path("/home/umbrel/umbrel")
BRANDING_DIR = DATA_DIR / "nodeblaster-branding"
LOG_PATH = BRANDING_DIR / "apply.log"
LOCK_PATH = Path("/run/nodeblaster-branding.lock")
WALLPAPER_SCRIPT = DATA_DIR / "custom-wallpapers" / "replace-existing-wallpapers.py"
UMBREL_YAML = DATA_DIR / "umbrel.yaml"
UMBREL_APP_SCRIPT_TS = Path("/opt/umbreld/source/modules/apps/legacy-compat/app-script.ts")
PRIVATE_WIDGET_APP_ID = "nodeblaster-miner-widget"
PRIVATE_WIDGET_STORE_DIR = DATA_DIR / "app-stores" / "nodeblaster-private" / PRIVATE_WIDGET_APP_ID
PRIVATE_WIDGET_ICON_HREF = "/assets/nodeblaster-miner-widget-icon.png"
PRIVATE_WIDGET_ICON_ASSET = Path("/opt/umbreld/ui/assets/nodeblaster-miner-widget-icon.png")
PRIVATE_WIDGET_APP_DIRS = [
    DATA_DIR / "app-data" / PRIVATE_WIDGET_APP_ID,
    PRIVATE_WIDGET_STORE_DIR,
    DATA_DIR / "nodeblaster-updater" / "apps" / PRIVATE_WIDGET_APP_ID,
]
DEVICE_SOURCE = Path("/opt/umbreld/source/modules/system/system.ts")
DEVICE_BACKUP = Path("/opt/umbreld/source/modules/system/system.ts.pre-nodeblaster-device-20260613")
IDENTITY_FILE = DATA_DIR / "nodeblaster-identity" / "unit.json"
DMI_PRODUCT_NAME = Path("/sys/devices/virtual/dmi/id/product_name")
UI_DIR = Path("/opt/umbreld/ui")
UI_INDEX = UI_DIR / "index.html"
STATUS_LINK_ASSET = UI_DIR / "assets" / "nodeblaster-status-link.js"
STATUS_LINK_BACKUP = UI_INDEX.with_name("index.html.pre-nodeblaster-status-link-20260617")
STATUS_LINK_SRC = "/assets/nodeblaster-status-link.js?v=20260926-umbrel2-compatibility-v1"
STATUS_LINK_SCRIPT_TAG = f'<script defer src="{STATUS_LINK_SRC}"></script>'
BROWSER_BRANDING_ASSET = UI_DIR / "assets" / "nodeblaster-browser-branding.js"
BCH_MEMPOOL_APP_ID = "nodeblaster-blockchair-bch-mempool"
BCH_MEMPOOL_ICON_HREF = "/assets/nodeblaster-bch-mempool-icon.svg"
BCH_MEMPOOL_ICON_ASSET = UI_DIR / "assets" / "nodeblaster-bch-mempool-icon.svg"
BCH_MEMPOOL_NAME = "Mempools"
BCH_MEMPOOL_WEBSITE = "https://blockchair.com/explorers"
BCH_MEMPOOL_APP_DIRS = [
    DATA_DIR / "app-data" / BCH_MEMPOOL_APP_ID,
    DATA_DIR / "nodeblaster-community-store" / BCH_MEMPOOL_APP_ID,
    DATA_DIR / "app-stores" / "cnmne-nodeblaster-umbrel-community-store-github-d10fbcab" / BCH_MEMPOOL_APP_ID,
]
BROWSER_BRANDING_SRC = "/assets/nodeblaster-browser-branding.js?v=20261003-approved-favicon-v1"
BROWSER_BRANDING_SCRIPT_TAG = f'<script defer src="{BROWSER_BRANDING_SRC}"></script>'
BROWSER_BRANDING_FAVICON_HREF = "/assets/nodeblaster-miner-widget-icon.png?v=20261003-approved-favicon-v1"
VERSION_MARKER = Path("/etc/nodeblaster-branding-version")
VERSION = "2026-10-03-approved-favicon-v1"
NPM_APP_ID = "nginx-proxy-manager"
NPM_APP_DATA_DIR = DATA_DIR / "app-data" / NPM_APP_ID
NPM_COMPOSE = NPM_APP_DATA_DIR / "docker-compose.yml"
NPM_DATA_DIR = NPM_APP_DATA_DIR / "data" / "npm-data"
NPM_SSL_DIR = NPM_DATA_DIR / "custom-ssl" / "nodeblaster-local"
NPM_CUSTOM_DIR = NPM_DATA_DIR / "nginx" / "custom"
NPM_HTTP_CONF = NPM_CUSTOM_DIR / "http.conf"
NPM_CA_KEY = NPM_SSL_DIR / "nodeblaster-local-ca.key"
NPM_CA_CERT = NPM_SSL_DIR / "nodeblaster-local-ca.crt"
NPM_SERVER_KEY = NPM_SSL_DIR / "nodeblaster.local.key"
NPM_SERVER_CSR = NPM_SSL_DIR / "nodeblaster.local.csr"
NPM_SERVER_CERT = NPM_SSL_DIR / "nodeblaster.local.crt"
NPM_SERVER_NAME = f"{HOSTNAME}.local"
DISPLAY_SCRIPT = DATA_DIR / "nodeblaster-display" / "display.py"
DISPLAY_CONFIG = DATA_DIR / "nodeblaster-display" / "display-config.json"
DISPLAY_SERVICE = Path("/etc/systemd/system/nodeblaster-display.service")
HASHWATCHER_ALLOW_PATH = DATA_DIR / "nodeblaster-security" / "hashwatcher-firewall.allow"
SYSTEMD_UNITS = {
    Path("/etc/systemd/system/nodeblaster-branding.service"): """[Unit]
Description=Apply NodeBlaster Umbrel branding
After=local-fs.target network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/bin/python3 /home/umbrel/umbrel/nodeblaster-branding/apply.py --mode identity
TimeoutStartSec=2min
Nice=10
IOSchedulingClass=idle

[Install]
WantedBy=multi-user.target
""",
    Path("/etc/systemd/system/nodeblaster-branding.timer"): """[Unit]
Description=Periodically reapply NodeBlaster Umbrel branding

[Timer]
OnBootSec=10min
OnUnitActiveSec=6h
Persistent=true

[Install]
WantedBy=timers.target
""",
    Path("/etc/systemd/system/nodeblaster-status.service"): """[Unit]
Description=NodeBlaster local update status service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /home/umbrel/umbrel/nodeblaster-status/status_server.py
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
""",
    Path("/etc/systemd/system/nodeblaster-updater.service"): """[Unit]
Description=Check for signed NodeBlaster unit updates
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/bin/python3 /home/umbrel/umbrel/nodeblaster-updater/update.py
TimeoutStartSec=5min
Nice=10
IOSchedulingClass=idle

[Install]
WantedBy=multi-user.target
""",
    Path("/etc/systemd/system/nodeblaster-updater.timer"): """[Unit]
Description=Check for NodeBlaster unit updates twice daily

[Timer]
OnBootSec=20min
OnUnitActiveSec=12h
RandomizedDelaySec=45min
Persistent=true

[Install]
WantedBy=timers.target
""",
    Path("/etc/systemd/system/nodeblaster-hashwatcher-firewall.service"): """[Unit]
Description=Restrict HashWatcher LAN API exposure
After=docker.service network-online.target
Wants=docker.service network-online.target
Before=umbrel.service

[Service]
Type=oneshot
ExecStart=/home/umbrel/umbrel/nodeblaster-security/apply-hashwatcher-firewall.sh apply

[Install]
WantedBy=multi-user.target
""",
    Path("/etc/systemd/system/nodeblaster-hashwatcher-firewall.timer"): """[Unit]
Description=Reapply HashWatcher firewall policy

[Timer]
OnBootSec=30s
OnUnitActiveSec=5min
Persistent=true
Unit=nodeblaster-hashwatcher-firewall.service

[Install]
WantedBy=timers.target
""",
}
DISPLAY_SERVICE_TEMPLATE = """[Unit]
Description=NodeBlaster local display animation
After=local-fs.target
ConditionPathExists=/dev/fb0

[Service]
Type=simple
ExecStart=/usr/bin/python3 /home/umbrel/umbrel/nodeblaster-display/display.py --duration 0 --style config --fps 10 --metric-refresh 10
ExecStopPost=/usr/bin/python3 /home/umbrel/umbrel/nodeblaster-display/display.py --style config --restore-console-if-config-console
Restart=on-failure
RestartSec=5
Nice=15
CPUWeight=20
CPUQuota=50%
IOSchedulingClass=idle

[Install]
WantedBy=multi-user.target
"""
UPDATE_PROCESS_KEYWORDS = (
    "umbrel-update",
    "umbrel update",
    "umbrel-updater",
    "umbreld update",
    "apt ",
    "apt-get",
    "apt.systemd.daily",
    "dpkg",
    "unattended-upgrade",
)
UPDATE_SERVICE_SUBJECT = "umbrel"
UPDATE_SERVICE_ACTIONS = ("update", "upgrade")


def log(message: str) -> None:
    timestamp = _dt.datetime.now(_dt.timezone.utc).astimezone().isoformat(timespec="seconds")
    line = f"[{timestamp}] {message}"
    try:
        BRANDING_DIR.mkdir(parents=True, exist_ok=True)
        with LOG_PATH.open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")
    except Exception:
        print(line)


def run(
    command: list[str],
    *,
    check: bool = False,
    log_output: bool = True,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, text=True, capture_output=True, env=env)
    if log_output and result.stdout.strip():
        log(f"{command[0]} stdout: {result.stdout.strip()}")
    if log_output and result.stderr.strip():
        log(f"{command[0]} stderr: {result.stderr.strip()}")
    if check and result.returncode != 0:
        raise RuntimeError(f"{command!r} failed with {result.returncode}")
    return result


def configure_nodeblaster_dual_audio() -> None:
    required_tools = ("aplay", "amixer", "alsactl")
    if not all(shutil.which(tool) for tool in required_tools):
        if not shutil.which("apt-get"):
            raise RuntimeError("apt-get is required to install alsa-utils")
        run(["apt-get", "update", "-qq"], check=True)
        run(
            ["apt-get", "install", "-y", "alsa-utils"],
            check=True,
            env={**os.environ, "DEBIAN_FRONTEND": "noninteractive"},
        )
    if not all(shutil.which(tool) for tool in required_tools):
        raise RuntimeError("alsa-utils did not provide the expected audio tools")

    result = run(["amixer", "-c", "0", "sset", "Master", "80%", "unmute"], check=False)
    if result.returncode != 0:
        log("Analog Master control is unavailable; leaving mixer state unchanged")
        return

    run(["alsactl", "store", "0"], check=True)
    log("Configured analog Master at 80%, unmuted, and saved ALSA state")


def backup_path(path: Path, label: str) -> Path:
    stamp = _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%d%H%M%S")
    return path.with_name(f"{path.name}.pre-nodeblaster-{label}-{stamp}")


def acquire_lock():
    LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    handle = LOCK_PATH.open("w", encoding="utf-8")
    try:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        log("Another NodeBlaster branding run is already active; skipping")
        handle.close()
        return None
    handle.write(f"{os.getpid()}\n")
    handle.flush()
    return handle


def update_activity_reason() -> str | None:
    if shutil.which("systemctl"):
        services = run(
            [
                "systemctl",
                "list-units",
                "--type=service",
                "--state=activating,active,running",
                "--no-legend",
                "--no-pager",
            ],
            log_output=False,
        )
        for line in services.stdout.splitlines():
            lower = line.lower()
            if UPDATE_SERVICE_SUBJECT in lower and any(action in lower for action in UPDATE_SERVICE_ACTIONS):
                return f"active update-related service: {line.strip()}"

    processes = run(["ps", "-eo", "pid=,comm=,args="], log_output=False)
    for line in processes.stdout.splitlines():
        lower = line.lower()
        if "nodeblaster-branding" in lower or "apply.py" in lower:
            continue
        if any(keyword in lower for keyword in UPDATE_PROCESS_KEYWORDS):
            return f"active update-related process: {line.strip()}"

    return None


def apply_hostname() -> None:
    hostname_path = Path("/etc/hostname")
    hosts_path = Path("/etc/hosts")

    current = hostname_path.read_text(encoding="utf-8").strip() if hostname_path.exists() else ""
    if current != HOSTNAME:
        hostname_path.write_text(HOSTNAME + "\n", encoding="utf-8")
        log(f"Updated /etc/hostname from {current!r} to {HOSTNAME!r}")
    else:
        log("/etc/hostname already set")

    lines = hosts_path.read_text(encoding="utf-8").splitlines() if hosts_path.exists() else []
    kept: list[str] = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("127.0.0.1") or stripped.startswith("127.0.1.1"):
            continue
        kept.append(line)
    new_lines = ["127.0.0.1 localhost", f"127.0.1.1 {HOSTNAME}", *kept]
    hosts_path.write_text("\n".join(new_lines).rstrip() + "\n", encoding="utf-8")
    log("Ensured /etc/hosts maps nodeblaster locally")

    runtime = run(["hostname"]).stdout.strip()
    if runtime != HOSTNAME:
        if shutil.which("hostnamectl"):
            result = run(["hostnamectl", "set-hostname", HOSTNAME])
            if result.returncode != 0:
                run(["hostname", HOSTNAME])
        else:
            run(["hostname", HOSTNAME])
        log("Updated runtime hostname")
    else:
        log("Runtime hostname already set")

    if shutil.which("systemctl"):
        run(["systemctl", "restart", "avahi-daemon.service"])


def apply_wallpapers() -> None:
    if not WALLPAPER_SCRIPT.exists():
        log(f"Wallpaper script not found: {WALLPAPER_SCRIPT}")
        return
    run(["python3", str(WALLPAPER_SCRIPT)])


def set_default_wallpaper() -> None:
    if not UMBREL_YAML.exists():
        log(f"Umbrel config not found: {UMBREL_YAML}")
        return

    lines = UMBREL_YAML.read_text(encoding="utf-8").splitlines()
    output: list[str] = []
    in_user = False
    changed = False

    for line in lines:
        if line == "user:":
            in_user = True
            output.append(line)
            continue

        if in_user and line and not line.startswith(" "):
            if not changed:
                output.append("  wallpaper: '1'")
                changed = True
            in_user = False

        if in_user and line.startswith("  wallpaper:"):
            if line.strip() == "wallpaper: '1'":
                log("Default wallpaper already set to slot 1")
                return
            output.append("  wallpaper: '1'")
            changed = True
        else:
            output.append(line)

    if in_user and not changed:
        output.append("  wallpaper: '1'")
        changed = True

    if not changed:
        log("Umbrel config has no user section for wallpaper default")
        return

    backup = UMBREL_YAML.with_name(
        f"umbrel.yaml.pre-nodeblaster-wallpaper-1-{_dt.datetime.now(_dt.timezone.utc).strftime('%Y%m%d%H%M%S')}"
    )
    backup.write_bytes(UMBREL_YAML.read_bytes())
    UMBREL_YAML.write_text("\n".join(output).rstrip() + "\n", encoding="utf-8")
    log("Set Umbrel selected wallpaper to slot 1")


def apply_device_patch() -> None:
    if not DEVICE_SOURCE.exists():
        log(f"Device source not found: {DEVICE_SOURCE}")
        return

    marker = "Local customization: display recognized NodeBlaster hardware"
    needle = "\tlet device = productName // TODO: Maybe format this better in the future.\n"
    legacy_insert = (
        "\tlet device = productName // TODO: Maybe format this better in the future.\n"
        "\t// Local customization: display this NUC as NodeBlaster in the Umbrel device info UI.\n"
        "\tif (productName === 'NUC7i7BNH') device = 'NodeBlaster'\n"
    )
    insert = (
        "\tlet device = productName // TODO: Maybe format this better in the future.\n"
        "\t// Local customization: display recognized NodeBlaster hardware in the Umbrel device info UI.\n"
        "\tif (productName === 'NUC7i7BNH' || productName === 'Nobilis') device = 'NodeBlaster'\n"
    )

    if not DEVICE_BACKUP.exists():
        DEVICE_BACKUP.write_bytes(DEVICE_SOURCE.read_bytes())
        log(f"Backed up device source to {DEVICE_BACKUP}")

    text = DEVICE_SOURCE.read_text(encoding="utf-8")
    if marker in text:
        log("Device patch already present")
        return

    if legacy_insert in text:
        DEVICE_SOURCE.write_text(text.replace(legacy_insert, insert, 1), encoding="utf-8")
        log("Upgraded NodeBlaster device-name override")
        return

    if needle not in text:
        log("Device patch insertion point not found")
        return

    DEVICE_SOURCE.write_text(text.replace(needle, insert, 1), encoding="utf-8")
    log("Applied NodeBlaster device-name override")


def ensure_customer_profile_identity() -> None:
    if not IDENTITY_FILE.exists():
        log(f"Unit identity not found: {IDENTITY_FILE}")
        return

    data = json.loads(IDENTITY_FILE.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        log("Unit identity is not a JSON object")
        return
    if str(data.get("display_profile") or "").strip():
        log("Customer-facing profile already assigned")
        return

    product_profile = str(data.get("product_profile") or "").strip().lower()
    dmi_product_name = (
        DMI_PRODUCT_NAME.read_text(encoding="utf-8").strip().lower()
        if DMI_PRODUCT_NAME.exists()
        else ""
    )
    if product_profile != "pro" or dmi_product_name != "nobilis":
        log("Customer-facing profile does not require a Proto repair")
        return

    backup = IDENTITY_FILE.with_name("unit.json.pre-nodeblaster-display-profile")
    if not backup.exists():
        backup.write_bytes(IDENTITY_FILE.read_bytes())
    data["display_profile"] = "Proto"
    temporary = IDENTITY_FILE.with_name("unit.json.nodeblaster-branding.tmp")
    temporary.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.chmod(temporary, 0o644)
    temporary.replace(IDENTITY_FILE)
    log("Assigned customer-facing profile Proto; canonical routing remains pro")


def apply_status_link() -> None:
    if not UI_INDEX.exists():
        log(f"Umbrel UI index not found: {UI_INDEX}")
        return

    STATUS_LINK_ASSET.parent.mkdir(parents=True, exist_ok=True)
    STATUS_LINK_ASSET.write_text(
        """(() => {
  const id = "nodeblaster-status-link";
  const wallpaperCacheKey = "20260926-umbrel2-compatibility-v1";
  let widgetFocusDone = false;

  const routeMinerWidgetLauncher = (event) => {
    const target = event.target instanceof Element ? event.target : null;
    const launcher = target?.closest("button, a, [role='button']");
    if (!launcher) return;
    const icon = launcher.querySelector("img[src*='nodeblaster-miner-widget-icon']");
    const named = launcher.textContent?.includes("NodeBlaster Miners");
    if (!icon && !named) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    window.location.assign("/edit-widgets");
  };

  document.addEventListener("click", routeMinerWidgetLauncher, true);

  const focusRequestedWidget = () => {
    if (widgetFocusDone || window.location.pathname !== "/edit-widgets") return;
    const requested = new URLSearchParams(window.location.search).get("focus-widget");
    if (requested !== "nodeblaster-miner-widget:miner-summary") return;
    const heading = [...document.querySelectorAll("h3")]
      .find((element) => element.textContent?.trim() === "NodeBlaster Miners");
    if (!heading) return;
    const group = heading.parentElement?.parentElement;
    if (!group) return;
    widgetFocusDone = true;
    group.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
    Object.assign(group.style, {
      borderRadius: "16px",
      outline: "3px solid rgba(247, 184, 79, 0.96)",
      outlineOffset: "8px",
      boxShadow: "0 0 36px rgba(247, 184, 79, 0.55)"
    });
    const widgetButton = group.querySelector("button");
    if (widgetButton) widgetButton.focus({ preventScroll: true });
    window.history.replaceState({}, "", "/edit-widgets");
    window.setTimeout(() => {
      group.style.outline = "";
      group.style.outlineOffset = "";
      group.style.boxShadow = "";
    }, 5000);
  };

  const cacheBustWallpaperUrl = (value) => {
    if (!value || !value.includes("/assets/wallpapers/")) return value;
    return value.replace(/\\/assets\\/wallpapers\\/[^,'")\\s]+/g, (url) => {
      if (url.includes("nbwp=")) return url;
      return `${url}${url.includes("?") ? "&" : "?"}nbwp=${wallpaperCacheKey}`;
    });
  };

  const refreshElement = (element) => {
    if (!element || !element.getAttribute) return;
    const src = element.getAttribute("src");
    const nextSrc = cacheBustWallpaperUrl(src);
    if (nextSrc !== src) element.setAttribute("src", nextSrc);

    const srcset = element.getAttribute("srcset");
    const nextSrcset = cacheBustWallpaperUrl(srcset);
    if (nextSrcset !== srcset) element.setAttribute("srcset", nextSrcset);

    const style = element.getAttribute("style");
    const nextStyle = cacheBustWallpaperUrl(style);
    if (nextStyle !== style) element.setAttribute("style", nextStyle);
  };

  const refreshWallpaperAssets = (root = document) => {
    refreshElement(root);
    if (!root.querySelectorAll) return;
    for (const element of root.querySelectorAll("[src], [srcset], [style]")) {
      const src = element.getAttribute("src");
      const nextSrc = cacheBustWallpaperUrl(src);
      if (nextSrc !== src) element.setAttribute("src", nextSrc);

      const srcset = element.getAttribute("srcset");
      const nextSrcset = cacheBustWallpaperUrl(srcset);
      if (nextSrcset !== srcset) element.setAttribute("srcset", nextSrcset);

      const style = element.getAttribute("style");
      const nextStyle = cacheBustWallpaperUrl(style);
      if (nextStyle !== style) element.setAttribute("style", nextStyle);
    }
  };

  const append = () => {
    if (!document.body || document.getElementById(id)) return;
    const baseUrl = `${window.location.protocol}//${window.location.hostname}:60016`;
    const root = document.createElement("div");
    root.id = id;
    const button = document.createElement("button");
    const label = document.createElement("span");
    const icon = document.createElement("span");
    const menu = document.createElement("div");
    const items = [
      ["NodeBlaster Updates", "/?check=1"],
      ["MinerControl", "/miners"],
      ["HashDrags", "/miner-race"]
    ];
    button.type = "button";
    button.setAttribute("aria-label", "NodeBlaster menu");
    button.setAttribute("aria-expanded", "false");
    icon.textContent = "\\u2630";
    label.textContent = "NodeBlaster";
    icon.className = "nodeblaster-status-link-icon";
    label.className = "nodeblaster-status-link-label";
    button.append(icon, label);
    menu.id = `${id}-menu`;
    menu.setAttribute("role", "menu");
    for (const [text, path] of items) {
      const link = document.createElement("a");
      link.href = `${baseUrl}${path}`;
      link.textContent = text;
      link.setAttribute("role", "menuitem");
      menu.appendChild(link);
    }
    Object.assign(root.style, {
      position: "fixed",
      right: "16px",
      bottom: "16px",
      zIndex: "2147483647"
    });
    Object.assign(button.style, {
      display: "inline-flex",
      alignItems: "center",
      gap: "8px",
      padding: "10px 13px",
      borderRadius: "999px",
      background: "rgba(247, 184, 79, 0.96)",
      color: "#17120b",
      font: "600 13px/1.2 system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
      cursor: "pointer",
      boxShadow: "0 8px 24px rgba(0, 0, 0, 0.35)",
      border: "1px solid rgba(255, 255, 255, 0.25)"
    });
    Object.assign(menu.style, {
      position: "absolute",
      right: "0",
      bottom: "calc(100% + 8px)",
      minWidth: "190px",
      display: "none",
      overflow: "hidden",
      borderRadius: "14px",
      background: "rgba(20, 16, 11, 0.97)",
      boxShadow: "0 14px 34px rgba(0, 0, 0, 0.42)",
      border: "1px solid rgba(247, 184, 79, 0.36)"
    });
    for (const link of menu.querySelectorAll("a")) {
      Object.assign(link.style, {
        display: "block",
        padding: "12px 14px",
        color: "#f6ead4",
        font: "600 13px/1.2 system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        textDecoration: "none",
        whiteSpace: "nowrap",
        borderBottom: "1px solid rgba(247, 184, 79, 0.16)"
      });
      link.addEventListener("mouseenter", () => { link.style.background = "rgba(247, 184, 79, 0.14)"; });
      link.addEventListener("mouseleave", () => { link.style.background = "transparent"; });
    }
    const style = document.createElement("style");
    style.textContent = `
      button[class*="h-[var(--app-h)]"][class*="py-3"] {
        padding-top: 0.5rem !important;
        padding-bottom: 0.5rem !important;
      }
      @media (max-width: 720px) {
        #${id} { bottom: calc(82px + env(safe-area-inset-bottom, 0px)) !important; right: 12px !important; }
        #${id} button { width: 44px !important; height: 44px !important; padding: 0 !important; justify-content: center !important; }
        #${id} .nodeblaster-status-link-label { display: none !important; }
        #${id} .nodeblaster-status-link-icon { font-size: 22px !important; line-height: 1 !important; }
      }
    `;
    const setOpen = (open) => {
      menu.style.display = open ? "block" : "none";
      button.setAttribute("aria-expanded", open ? "true" : "false");
    };
    button.addEventListener("click", (event) => {
      event.stopPropagation();
      setOpen(menu.style.display !== "block");
    });
    document.addEventListener("click", () => setOpen(false));
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") setOpen(false);
    });
    root.append(button, menu, style);
    document.body.appendChild(root);
  };
  const apply = () => {
    append();
    refreshWallpaperAssets();
    focusRequestedWidget();
  };
  apply();
  document.addEventListener("DOMContentLoaded", apply, { once: true });
  new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (mutation.type === "attributes") {
        refreshWallpaperAssets(mutation.target.parentElement || document);
      } else {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE) refreshWallpaperAssets(node);
        }
      }
    }
  }).observe(document.documentElement, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["src", "srcset", "style"]
  });
})();
""",
        encoding="utf-8",
    )
    log(f"Wrote Umbrel GUI status link asset: {STATUS_LINK_ASSET}")

    text = UI_INDEX.read_text(encoding="utf-8")
    if STATUS_LINK_SCRIPT_TAG in text:
        log("Umbrel GUI status link script tag already current")
        return

    if not STATUS_LINK_BACKUP.exists():
        STATUS_LINK_BACKUP.write_bytes(UI_INDEX.read_bytes())
        log(f"Backed up Umbrel UI index to {STATUS_LINK_BACKUP}")

    text = text.replace('<script defer src="/assets/nodeblaster-status-link.js"></script>', "")
    text = text.replace('<script defer src="/assets/nodeblaster-status-link.js?v=20260617-wallpaper-cache-v1"></script>', "")
    text = text.replace('<script defer src="/assets/nodeblaster-status-link.js?v=20260626-home-update-check-v1"></script>', "")
    text = text.replace('<script defer src="/assets/nodeblaster-status-link.js?v=20260709-mobile-menu-v1"></script>', "")
    text = text.replace('<script defer src="/assets/nodeblaster-status-link.js?v=20260711-widget-focus-v1"></script>', "")
    text = text.replace('<script defer src="/assets/nodeblaster-status-link.js?v=20260711-same-page-menu-v1"></script>', "")
    text = text.replace('<script defer src="/assets/nodeblaster-status-link.js?v=20260721-widget-routing-v1"></script>', "")

    if "</head>" not in text:
        log("Umbrel UI index has no </head> insertion point")
        return

    UI_INDEX.write_text(text.replace("</head>", f"  {STATUS_LINK_SCRIPT_TAG}\n  </head>", 1), encoding="utf-8")
    log("Injected Umbrel GUI status link script tag")


def browser_branding_script() -> str:
    return f"""(() => {{
  const title = "NodeBlaster";
  const faviconHref = "{BROWSER_BRANDING_FAVICON_HREF}";

  const setTitle = () => {{
    if (document.title !== title) document.title = title;
  }};

  const ensureFavicon = () => {{
    if (!document.head) return;
    document.querySelectorAll('link[rel~="icon"], link[rel="apple-touch-icon"], link[rel="manifest"]').forEach((candidate) => {{
      if (candidate.getAttribute("data-nodeblaster-favicon") !== "true") candidate.remove();
    }});
    let icon = document.querySelector('link[data-nodeblaster-favicon="true"]');
    if (!icon) {{
      icon = document.createElement("link");
      icon.setAttribute("data-nodeblaster-favicon", "true");
      document.head.appendChild(icon);
    }}
    icon.rel = "icon";
    icon.type = "image/png";
    if (icon.href !== new URL(faviconHref, window.location.origin).href) {{
      icon.href = faviconHref;
    }}
  }};

  const apply = () => {{
    setTitle();
    ensureFavicon();
  }};

  apply();
  document.addEventListener("DOMContentLoaded", apply, {{ once: true }});
  new MutationObserver(apply).observe(document.documentElement, {{
    childList: true,
    subtree: true
  }});
}})();
"""


def bch_mempool_icon_svg() -> str:
    return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" role="img" aria-label="BCH Mempool">
  <defs>
    <linearGradient id="bg" x1="64" y1="52" x2="448" y2="460" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#0AC18E"/>
      <stop offset="1" stop-color="#047C5D"/>
    </linearGradient>
    <linearGradient id="coin" x1="152" y1="110" x2="360" y2="402" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="#F5FFF6"/>
      <stop offset="1" stop-color="#D7FFE5"/>
    </linearGradient>
    <filter id="shadow" x="-30%" y="-30%" width="160%" height="160%">
      <feDropShadow dx="0" dy="18" stdDeviation="18" flood-color="#023526" flood-opacity="0.36"/>
    </filter>
  </defs>
  <rect width="512" height="512" rx="112" fill="url(#bg)"/>
  <path d="M112 118h288v276H112z" fill="#063B31" opacity="0.18"/>
  <path d="M130 136h252v240H130z" fill="none" stroke="#D9FFF0" stroke-width="22" stroke-linejoin="round" opacity="0.95"/>
  <path d="M130 214h252M130 296h252M214 136v240M298 136v240" fill="none" stroke="#D9FFF0" stroke-width="18" opacity="0.78"/>
  <circle cx="256" cy="256" r="122" fill="url(#coin)" filter="url(#shadow)"/>
  <circle cx="256" cy="256" r="103" fill="none" stroke="#068A66" stroke-width="15" opacity="0.92"/>
  <g transform="translate(256 256) rotate(-14) translate(-256 -256)">
    <path d="M222 158h44c39 0 64 19 64 50 0 20-10 35-28 44 24 8 38 25 38 51 0 35-27 55-70 55h-58l20-200Zm39 82c20 0 32-9 32-25 0-14-11-22-30-22h-10l-9 47h17Zm-15 82h22c22 0 35-10 35-27 0-16-13-24-36-24h-28l-10 51h17Z" fill="#047C5D"/>
    <path d="M252 133h27l-9 44h-27l9-44Zm-42 0h27l-9 44h-27l9-44Zm64 202h27l-9 44h-27l9-44Zm-42 0h27l-9 44h-27l9-44Z" fill="#047C5D"/>
  </g>
</svg>
"""


def ensure_bch_mempool_shortcut_icon() -> None:
    if write_if_changed(BCH_MEMPOOL_ICON_ASSET, bch_mempool_icon_svg(), backup_label="bch-mempool-icon", mode=0o644):
        log(f"Wrote Mempools icon asset: {BCH_MEMPOOL_ICON_ASSET}")
    else:
        log("Mempools icon asset already current")

    for app_dir in BCH_MEMPOOL_APP_DIRS:
        app_manifest = app_dir / "umbrel-app.yml"
        if not app_manifest.exists():
            continue
        text = app_manifest.read_text(encoding="utf-8")
        updated = re.sub(r"^name:\s*.*$", f"name: {BCH_MEMPOOL_NAME}", text, count=1, flags=re.MULTILINE)
        updated = re.sub(r"^website:\s*.*$", f"website: {BCH_MEMPOOL_WEBSITE}", updated, count=1, flags=re.MULTILINE)
        updated = re.sub(r"^icon:\s*.*$", f"icon: {BCH_MEMPOOL_ICON_HREF}", updated, count=1, flags=re.MULTILINE)
        updated = re.sub(
            r"(?ms)^gallery:\n(?:\s+- .*\n)+",
            f"gallery:\n  - {BCH_MEMPOOL_ICON_HREF}\n",
            updated,
            count=1,
        )
        if updated == text:
            log(f"Mempools shortcut metadata already current: {app_manifest}")
            continue
        backup = backup_path(app_manifest, "bch-mempool-icon")
        backup.write_bytes(app_manifest.read_bytes())
        app_manifest.write_text(updated, encoding="utf-8")
        shutil.chown(app_manifest, user="umbrel", group="umbrel")
        log(f"Updated Mempools shortcut metadata: {app_manifest}; backup={backup}")


def apply_browser_branding() -> None:
    if not UI_INDEX.exists():
        log(f"Umbrel UI index not found: {UI_INDEX}")
        return

    if write_if_changed(BROWSER_BRANDING_ASSET, browser_branding_script()):
        log(f"Wrote NodeBlaster browser branding asset: {BROWSER_BRANDING_ASSET}")
    else:
        log("NodeBlaster browser branding asset already current")

    text = UI_INDEX.read_text(encoding="utf-8")
    original = text

    text = re.sub(r"<title>.*?</title>", "<title>NodeBlaster</title>", text, count=1, flags=re.IGNORECASE | re.DOTALL)
    if "<title" not in text.lower():
        text = text.replace("</head>", "  <title>NodeBlaster</title>\n  </head>", 1)

    text = re.sub(
        r"\s*<link\b(?=[^>]*\brel=[\"'](?:icon|shortcut icon|apple-touch-icon|manifest)[\"'])[^>]*>",
        "",
        text,
        flags=re.IGNORECASE,
    )
    text = re.sub(
        r"\s*<script defer src=\"/assets/nodeblaster-browser-branding\.js[^\"]*\"></script>",
        "",
        text,
        flags=re.IGNORECASE,
    )

    favicon_tag = f'<link rel="icon" type="image/png" href="{BROWSER_BRANDING_FAVICON_HREF}" data-nodeblaster-favicon="true">'
    injection = f"  {favicon_tag}\n  {BROWSER_BRANDING_SCRIPT_TAG}\n"

    if "</head>" not in text:
        log("Umbrel UI index has no </head> insertion point for browser branding")
        return

    text = text.replace("</head>", f"{injection}  </head>", 1)

    if text == original:
        log("Umbrel browser title and favicon already current")
        return

    backup = backup_path(UI_INDEX, "browser-branding")
    backup.write_bytes(UI_INDEX.read_bytes())
    UI_INDEX.write_text(text, encoding="utf-8")
    log(f"Applied NodeBlaster browser title/favicon branding; backup={backup}")


def write_if_changed(path: Path, content: str, *, backup_label: str | None = None, mode: int | None = None) -> bool:
    current = path.read_text(encoding="utf-8") if path.exists() else None
    if current == content:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and backup_label:
        backup = backup_path(path, backup_label)
        backup.write_bytes(path.read_bytes())
        log(f"Backed up {path} to {backup}")
    path.write_text(content, encoding="utf-8")
    if mode is not None:
        os.chmod(path, mode)
    return True


def ensure_private_widget_app_store_lookup() -> None:
    if not UMBREL_APP_SCRIPT_TS.exists():
        log(f"Umbrel app-script source is missing: {UMBREL_APP_SCRIPT_TS}")
        return
    if not PRIVATE_WIDGET_STORE_DIR.is_dir():
        log(f"Private widget store is missing: {PRIVATE_WIDGET_STORE_DIR}")
        return

    text = UMBREL_APP_SCRIPT_TS.read_text(encoding="utf-8")
    original = text
    import_line = "import {existsSync} from 'node:fs'\n"
    import_marker = "import {fileURLToPath} from 'node:url'\n"
    fallback_marker = "\t// NodeBlaster private app-store fallback.\n"
    lookup_marker = (
        "\ttry {\n"
        "\t\tSCRIPT_APP_REPO_DIR = await umbreld.appStore.getAppTemplateFilePath(arg)\n"
        "\t} catch {}\n"
    )
    fallback = (
        fallback_marker
        + "\tif (!SCRIPT_APP_REPO_DIR && arg === 'nodeblaster-miner-widget') {\n"
        "\t\tconst privateAppRepoDir = join(umbreld.dataDirectory, 'app-stores', 'nodeblaster-private', arg)\n"
        "\t\tif (existsSync(privateAppRepoDir)) SCRIPT_APP_REPO_DIR = privateAppRepoDir\n"
        "\t}\n"
    )

    if import_line not in text:
        if import_marker not in text:
            raise RuntimeError("Could not find Umbrel app-script import marker")
        text = text.replace(import_marker, import_marker + import_line, 1)
    if fallback_marker not in text:
        if lookup_marker not in text:
            raise RuntimeError("Could not find Umbrel app-store lookup marker")
        text = text.replace(lookup_marker, lookup_marker + fallback, 1)

    if text == original:
        log("Private widget app-store lookup already configured")
        return
    write_if_changed(UMBREL_APP_SCRIPT_TS, text, backup_label="private-widget-store", mode=0o644)
    log("Configured Umbrel private widget app-store lookup")


def ensure_private_widget_icon() -> None:
    icon_source = next(
        (
            app_dir / "nodeblaster-miner-widget-icon.png"
            for app_dir in PRIVATE_WIDGET_APP_DIRS
            if (app_dir / "nodeblaster-miner-widget-icon.png").is_file()
        ),
        None,
    )
    if icon_source is None:
        log("Private widget icon source is missing")
        return

    icon_bytes = icon_source.read_bytes()
    if not PRIVATE_WIDGET_ICON_ASSET.is_file() or PRIVATE_WIDGET_ICON_ASSET.read_bytes() != icon_bytes:
        PRIVATE_WIDGET_ICON_ASSET.parent.mkdir(parents=True, exist_ok=True)
        PRIVATE_WIDGET_ICON_ASSET.write_bytes(icon_bytes)
        os.chown(PRIVATE_WIDGET_ICON_ASSET, 0, 0)
        os.chmod(PRIVATE_WIDGET_ICON_ASSET, 0o644)
        log(f"Restored private widget icon asset: {PRIVATE_WIDGET_ICON_ASSET}")
    else:
        log("Private widget icon asset already current")

    for app_dir in PRIVATE_WIDGET_APP_DIRS:
        manifest = app_dir / "umbrel-app.yml"
        if not manifest.is_file():
            continue
        text = manifest.read_text(encoding="utf-8")
        updated = re.sub(
            r"^icon:\s*.*$",
            f"icon: {PRIVATE_WIDGET_ICON_HREF}",
            text,
            count=1,
            flags=re.MULTILINE,
        )
        updated = updated.replace(
            "/assets/nodeblaster-miner-widget-icon-v2.png",
            PRIVATE_WIDGET_ICON_HREF,
        )
        if write_if_changed(manifest, updated, backup_label="private-widget-icon", mode=0o644):
            log(f"Repaired private widget icon metadata: {manifest}")


def ensure_nodeblaster_service_units() -> None:
    if not shutil.which("systemctl"):
        log("systemctl not found; skipping NodeBlaster service-unit repair")
        return

    changed = False
    for path, content in SYSTEMD_UNITS.items():
        changed |= write_if_changed(path, content, backup_label="service-unit", mode=0o644)

    status_server = DATA_DIR / "nodeblaster-status" / "status_server.py"
    updater = DATA_DIR / "nodeblaster-updater" / "update.py"
    if not status_server.exists():
        log(f"Status service source is missing: {status_server}")
    if not updater.exists():
        log(f"Updater source is missing: {updater}")

    if changed:
        run(["systemctl", "daemon-reload"])

    run(["systemctl", "enable", "nodeblaster-branding.service", "nodeblaster-branding.timer"])
    run(["systemctl", "restart", "nodeblaster-branding.timer"])

    if updater.exists():
        run(["systemctl", "enable", "nodeblaster-updater.service", "nodeblaster-updater.timer"])
        run(["systemctl", "restart", "nodeblaster-updater.timer"])

    if status_server.exists():
        run(["systemctl", "enable", "nodeblaster-status.service"])
        run(["systemctl", "restart", "nodeblaster-status.service"])

    firewall_source = DATA_DIR / "nodeblaster-security" / "apply-hashwatcher-firewall.sh"
    configured_sources = []
    if HASHWATCHER_ALLOW_PATH.is_file():
        configured_sources = [
            line.split("#", 1)[0].strip()
            for line in HASHWATCHER_ALLOW_PATH.read_text(encoding="utf-8").splitlines()
            if line.split("#", 1)[0].strip()
        ]
    if firewall_source.exists() and configured_sources:
        os.chmod(HASHWATCHER_ALLOW_PATH, 0o600)
        run(["systemctl", "start", "nodeblaster-hashwatcher-firewall.service"])
        run(["systemctl", "enable", "--now", "nodeblaster-hashwatcher-firewall.timer"])
    else:
        run(["systemctl", "disable", "--now", "nodeblaster-hashwatcher-firewall.timer"], check=False)


def hashwatcher_gateway_installed() -> bool:
    for base in (DATA_DIR / "app-data", DATA_DIR / "app-stores"):
        if base.exists() and any("hashwatcher" in path.name.lower() for path in base.glob("*")):
            return True
    try:
        with urllib.request.urlopen("http://127.0.0.1:8787/api/miner/data", timeout=0.3) as response:
            return response.status == 200
    except Exception:
        return False


def read_display_style() -> str | None:
    if not DISPLAY_CONFIG.exists():
        return None
    try:
        import json

        data = json.loads(DISPLAY_CONFIG.read_text(encoding="utf-8"))
    except Exception as error:
        log(f"Could not read display config: {error}")
        return None
    style = str(data.get("style") or "").strip().lower()
    return style if style in ("mesh", "orbit", "dashboard", "gauges", "fleet", "shares", "ticker", "slideshow", "carousel", "screensaver", "console") else None


def write_default_display_config() -> None:
    if read_display_style():
        log("Display config already set; preserving existing style")
        return
    style = "fleet"
    DISPLAY_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    DISPLAY_CONFIG.write_text(
        '{\n'
        f'  "style": "{style}",\n'
        '  "source": "nodeblaster-branding",\n'
        '  "note": "Default is selected during branding; the NodeBlaster Updates page may change it later."\n'
        '}\n',
        encoding="utf-8",
    )
    log(f"Seeded display config style={style}")


def apply_display_service_policy() -> None:
    if not shutil.which("systemctl"):
        log("systemctl not found; skipping display service policy")
        return
    if not DISPLAY_SCRIPT.exists() and not DISPLAY_SERVICE.exists():
        log("Display feature files are not installed; skipping display service policy")
        return

    write_default_display_config()
    style = read_display_style()
    content = DISPLAY_SERVICE_TEMPLATE
    if write_if_changed(DISPLAY_SERVICE, content, backup_label="display-policy", mode=0o644):
        run(["systemctl", "daemon-reload"])
        log("Updated display service policy")
    else:
        log("Display service policy already current")
    if style == "console":
        run(["systemctl", "disable", "--now", "nodeblaster-display.service"])
        log("Display config style=console; nodeblaster-display.service disabled for root console")
        return
    run(["systemctl", "enable", "nodeblaster-display.service"])
    if not Path("/dev/fb0").exists():
        log("Display service enabled; waiting for HDMI monitor to provide /dev/fb0")
        return
    run(["systemctl", "restart", "nodeblaster-display.service"])
    log("Ensured nodeblaster-display.service is enabled and active")


def npm_ca_config() -> str:
    return """[ req ]
distinguished_name = dn
x509_extensions = v3_ca
prompt = no
[ dn ]
CN = NodeBlaster Local CA
O = NodeBlaster
[ v3_ca ]
basicConstraints = critical, CA:true
keyUsage = critical, keyCertSign, cRLSign
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
"""


def npm_server_config() -> str:
    return f"""[ req ]
distinguished_name = dn
req_extensions = v3_req
prompt = no
[ dn ]
CN = {NPM_SERVER_NAME}
O = NodeBlaster
[ v3_req ]
basicConstraints = CA:false
keyUsage = critical, digitalSignature, keyEncipherment
extendedKeyUsage = serverAuth
subjectAltName = @alt_names
[ alt_names ]
DNS.1 = {NPM_SERVER_NAME}
DNS.2 = {HOSTNAME}
"""


def npm_proxy_config() -> str:
    return f"""server {{
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name {NPM_SERVER_NAME};

    ssl_certificate /data/custom-ssl/nodeblaster-local/nodeblaster.local.crt;
    ssl_certificate_key /data/custom-ssl/nodeblaster-local/nodeblaster.local.key;
    ssl_protocols TLSv1.2 TLSv1.3;

    location / {{
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;
        proxy_set_header X-Forwarded-Host $host;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_pass http://docker-host:80;
    }}
}}
"""


def find_umbrel_app_repo_dir(app_id: str) -> Path | None:
    app_stores = DATA_DIR / "app-stores"
    if not app_stores.exists():
        return None
    candidates = sorted(app_stores.glob(f"*/{app_id}/umbrel-app.yml"))
    if not candidates:
        return None
    return candidates[0].parent


def restart_umbrel_app(app_id: str) -> None:
    app_script = Path("/opt/umbreld/source/modules/apps/legacy-compat/app-script")
    repo_dir = find_umbrel_app_repo_dir(app_id)
    if not app_script.exists() or repo_dir is None:
        log(f"Could not restart Umbrel app {app_id}; app-script or repo dir missing")
        return
    env = {
        **os.environ,
        "SCRIPT_UMBREL_ROOT": str(DATA_DIR),
        "SCRIPT_APP_REPO_DIR": str(repo_dir),
        "SCRIPT_DOCKER_FRAGMENTS": "/opt/umbreld/source/modules/apps/legacy-compat",
        "REMOTE_TOR_ACCESS": "false",
    }
    result = subprocess.run([str(app_script), "restart", app_id], text=True, capture_output=True, env=env)
    if result.stdout.strip():
        log(f"{app_script.name} stdout: {result.stdout.strip()}")
    if result.stderr.strip():
        log(f"{app_script.name} stderr: {result.stderr.strip()}")
    if result.returncode != 0:
        log(f"Restarting Umbrel app {app_id} failed with {result.returncode}")


def ensure_npm_certificates() -> bool:
    if not shutil.which("openssl"):
        log("Skipping NodeBlaster local HTTPS setup because openssl is unavailable")
        return False

    NPM_SSL_DIR.mkdir(parents=True, exist_ok=True)
    ca_conf = NPM_SSL_DIR / "nodeblaster-local-ca.cnf"
    server_conf = NPM_SSL_DIR / "nodeblaster-local-server.cnf"
    changed = False
    changed |= write_if_changed(ca_conf, npm_ca_config(), mode=0o644)
    changed |= write_if_changed(server_conf, npm_server_config(), mode=0o644)

    if not NPM_CA_KEY.exists() or not NPM_CA_CERT.exists():
        run(["openssl", "genrsa", "-out", str(NPM_CA_KEY), "4096"], check=True)
        run(
            [
                "openssl",
                "req",
                "-x509",
                "-new",
                "-nodes",
                "-key",
                str(NPM_CA_KEY),
                "-sha256",
                "-days",
                "3650",
                "-out",
                str(NPM_CA_CERT),
                "-config",
                str(ca_conf),
            ],
            check=True,
        )
        changed = True
        log(f"Created NodeBlaster local CA at {NPM_CA_CERT}")

    if changed or not NPM_SERVER_KEY.exists() or not NPM_SERVER_CERT.exists():
        run(["openssl", "genrsa", "-out", str(NPM_SERVER_KEY), "2048"], check=True)
        run(
            [
                "openssl",
                "req",
                "-new",
                "-key",
                str(NPM_SERVER_KEY),
                "-out",
                str(NPM_SERVER_CSR),
                "-config",
                str(server_conf),
            ],
            check=True,
        )
        run(
            [
                "openssl",
                "x509",
                "-req",
                "-in",
                str(NPM_SERVER_CSR),
                "-CA",
                str(NPM_CA_CERT),
                "-CAkey",
                str(NPM_CA_KEY),
                "-CAcreateserial",
                "-out",
                str(NPM_SERVER_CERT),
                "-days",
                "825",
                "-sha256",
                "-extensions",
                "v3_req",
                "-extfile",
                str(server_conf),
            ],
            check=True,
        )
        changed = True
        log(f"Created NodeBlaster local HTTPS certificate at {NPM_SERVER_CERT}")

    for key_path in (NPM_CA_KEY, NPM_SERVER_KEY):
        if key_path.exists():
            os.chmod(key_path, 0o600)
    for cert_path in (NPM_CA_CERT, NPM_SERVER_CERT):
        if cert_path.exists():
            os.chmod(cert_path, 0o644)
    run(["chown", "-R", "1000:1000", str(NPM_SSL_DIR)])
    return changed


def ensure_npm_host_port_443() -> bool:
    if not NPM_COMPOSE.exists():
        return False
    text = NPM_COMPOSE.read_text(encoding="utf-8")
    if "'443:443'" in text or '"443:443"' in text:
        log("Nginx Proxy Manager already exposes host port 443")
        return False

    markers = ["      - '40443:443'\n", '      - "40443:443"\n']
    for marker in markers:
        if marker in text:
            updated = text.replace(marker, marker + "      - '443:443'\n", 1)
            backup = backup_path(NPM_COMPOSE, "local-https")
            backup.write_bytes(NPM_COMPOSE.read_bytes())
            NPM_COMPOSE.write_text(updated, encoding="utf-8")
            log(f"Added Nginx Proxy Manager host port 443; backup={backup}")
            return True

    log("Could not find Nginx Proxy Manager 40443 mapping; leaving compose unchanged")
    return False


def ensure_nodeblaster_local_https() -> None:
    if not NPM_COMPOSE.exists():
        log("Nginx Proxy Manager is not installed; skipping NodeBlaster local HTTPS setup")
        return
    if not shutil.which("openssl") and (not NPM_CA_CERT.exists() or not NPM_SERVER_CERT.exists()):
        log("Skipping NodeBlaster local HTTPS setup because openssl is unavailable and certificates are missing")
        return

    changed = False
    changed |= ensure_npm_certificates()
    changed |= ensure_npm_host_port_443()
    changed |= write_if_changed(NPM_HTTP_CONF, npm_proxy_config(), backup_label="local-https", mode=0o644)
    run(["chown", "1000:1000", str(NPM_HTTP_CONF)])

    if changed:
        restart_umbrel_app(NPM_APP_ID)
        log("Applied NodeBlaster local HTTPS proxy through Nginx Proxy Manager")
    else:
        log("NodeBlaster local HTTPS proxy already configured")


def write_version_marker() -> None:
    try:
        VERSION_MARKER.write_text(VERSION + "\n", encoding="utf-8")
    except Exception as error:
        log(f"Could not write version marker: {error}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Apply NodeBlaster Umbrel branding customizations.")
    parser.add_argument(
        "--mode",
        choices=("full", "identity"),
        default="full",
        help="full also reapplies wallpaper assets; identity preserves customer wallpaper choices.",
    )
    parser.add_argument(
        "--display-policy",
        choices=("preserve", "apply"),
        default="preserve",
        help="apply manages nodeblaster-display.service; preserve leaves the current display state alone.",
    )
    parser.add_argument(
        "--wallpaper-selection",
        choices=("default", "preserve"),
        default="preserve",
        help="preserve retains the current customer selection; default explicitly selects slot 1 during shop branding.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    if os.geteuid() != 0:
        log("NodeBlaster branding agent must run as root")
        return 1

    lock_handle = acquire_lock()
    if lock_handle is None:
        return 0

    log(f"Starting NodeBlaster branding agent {VERSION} mode={args.mode}")
    try:
        update_reason = update_activity_reason()
        if update_reason:
            log(f"Umbrel or OS update activity detected; skipping branding work: {update_reason}")
            return 0

        steps = [
            apply_hostname,
            ensure_customer_profile_identity,
            ensure_nodeblaster_service_units,
            apply_status_link,
            ensure_bch_mempool_shortcut_icon,
            ensure_private_widget_icon,
            apply_browser_branding,
            ensure_private_widget_app_store_lookup,
            apply_device_patch,
            ensure_nodeblaster_local_https,
            write_version_marker,
        ]
        if args.display_policy == "apply":
            steps.insert(2, apply_display_service_policy)
        else:
            log("Display service policy: preserving current display state")
        if args.mode == "full":
            steps.insert(1, apply_wallpapers)
            if args.wallpaper_selection == "default":
                steps.insert(2, set_default_wallpaper)
            else:
                log("Wallpaper selection policy: preserving current customer selection")
            steps.insert(3, configure_nodeblaster_dual_audio)
        else:
            log("Identity mode: preserving customer wallpaper and audio choices")

        for step in steps:
            try:
                step()
            except Exception as error:
                log(f"{step.__name__} failed: {error}")
        log("Finished NodeBlaster branding agent")
        return 0
    finally:
        fcntl.flock(lock_handle, fcntl.LOCK_UN)
        lock_handle.close()


if __name__ == "__main__":
    raise SystemExit(main())
