from pathlib import Path
import shutil
import subprocess

BASE = Path("/home/umbrel/umbrel/custom-wallpapers")
SOURCE_DIR = BASE / "source"
WALLPAPERS = Path("/opt/umbreld/ui/assets/wallpapers")

REPLACEMENTS = [(f"slot-{slot:02d}.jpg", slot) for slot in range(1, 13)]
LEGACY_DERIVATIVES = (
    ("generated-small", "800x800>", "86"),
    ("generated-thumbs", "200x200>", "82"),
)
AVIF_DERIVATIVES = (
    ("thumbnails", "200x113", "72"),
    ("small", "800x450", "76"),
    ("medium", "1440x810", "78"),
    ("large", "2880x1620", "80"),
)


def run(*args: str) -> None:
    subprocess.check_call(args)


def image_tool() -> str:
    for candidate in ("magick", "convert"):
        if shutil.which(candidate):
            return candidate
    raise RuntimeError("ImageMagick is required to generate Umbrel wallpaper derivatives")


def backup_once(path: Path) -> None:
    if not path.exists():
        return
    backup = path.with_suffix(path.suffix + ".stock-backup")
    if not backup.exists():
        shutil.copy2(path, backup)


IMAGE_TOOL = image_tool()


for filename, wallpaper_id in REPLACEMENTS:
    source = SOURCE_DIR / filename
    if not source.exists():
        raise FileNotFoundError(source)

    target = WALLPAPERS / f"{wallpaper_id}.jpg"
    backup_once(target)
    shutil.copy2(source, target)

    generated = [target]
    for directory, geometry, quality in LEGACY_DERIVATIVES:
        output_dir = WALLPAPERS / directory
        if not output_dir.is_dir():
            continue
        output = output_dir / f"{wallpaper_id}.jpg"
        backup_once(output)
        run(IMAGE_TOOL, str(target), "-resize", geometry, "-quality", quality, str(output))
        generated.append(output)

    avif_root = WALLPAPERS / "generated-avif"
    if avif_root.is_dir():
        for directory, geometry, quality in AVIF_DERIVATIVES:
            output_dir = avif_root / directory
            output_dir.mkdir(parents=True, exist_ok=True)
            output = output_dir / f"{wallpaper_id}.avif"
            backup_once(output)
            run(
                IMAGE_TOOL,
                str(target),
                "-auto-orient",
                "-resize",
                f"{geometry}^",
                "-gravity",
                "center",
                "-extent",
                geometry,
                "-quality",
                quality,
                str(output),
            )
            generated.append(output)

    for path in generated:
        path.chmod(0o644)

print("replaced existing Umbrel wallpapers and available derivatives: 1-12")
