#!/usr/bin/env python3
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import hmac
import importlib.util
import json
import os
import re
import secrets
import socketserver
import subprocess
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from typing import Any, Callable


VERSION = "0.1.2"
APP_DATA = Path(os.environ.get(
    "NODEBLASTER_CONTROL_APP_DATA",
    "/home/umbrel/umbrel/app-data/nodeblaster-control/data",
))
BRIDGE_DIR = APP_DATA / "host-bridge"
SOCKET_PATH = Path(os.environ.get("NODEBLASTER_CONTROL_SOCKET", str(BRIDGE_DIR / "bridge.sock")))
TOKEN_PATH = Path(os.environ.get("NODEBLASTER_CONTROL_TOKEN", str(BRIDGE_DIR / "token")))
DISPLAY_CONFIG = Path(os.environ.get(
    "NODEBLASTER_DISPLAY_CONFIG",
    "/home/umbrel/umbrel/nodeblaster-display/display-config.json",
))
DISPLAY_SCRIPT = Path(os.environ.get(
    "NODEBLASTER_DISPLAY_SCRIPT",
    "/home/umbrel/umbrel/nodeblaster-display/display.py",
))
UPDATER_PATH = Path(os.environ.get(
    "NODEBLASTER_UPDATER_PATH",
    "/home/umbrel/umbrel/nodeblaster-updater/update.py",
))
IDENTITY_PATH = Path(os.environ.get(
    "NODEBLASTER_IDENTITY_PATH",
    "/home/umbrel/umbrel/nodeblaster-identity/unit.json",
))
UPDATER_STATUS = Path(os.environ.get(
    "NODEBLASTER_UPDATER_STATUS",
    "/home/umbrel/umbrel/nodeblaster-updater/status.json",
))
CONTROL_LEASE_PATH = Path(os.environ.get(
    "NODEBLASTER_CONTROL_LEASE",
    "/home/umbrel/umbrel/nodeblaster-identity/control-entitlement-v2.json",
))
CONTROL_DENIAL_PATH = Path(os.environ.get(
    "NODEBLASTER_CONTROL_DENIAL",
    "/home/umbrel/umbrel/nodeblaster-identity/control-entitlement-denial.json",
))
SUITE_INITIALIZED_MARKER = Path(os.environ.get(
    "NODEBLASTER_SUITE_INITIALIZED_MARKER",
    "/home/umbrel/umbrel/nodeblaster-identity/suite-initialized",
))
BRANDING_LOG_PATH = Path(os.environ.get(
    "NODEBLASTER_BRANDING_LOG",
    "/home/umbrel/umbrel/nodeblaster-branding/apply.log",
))
DISCORD_WEBHOOK_PATH = Path(os.environ.get(
    "NODEBLASTER_DISCORD_WEBHOOK_FILE",
    "/home/umbrel/umbrel/nodeblaster-display/discord-webhook.url",
))
INSTALLATION_ID_PATH = Path(os.environ.get(
    "NODEBLASTER_INSTALLATION_ID",
    "/home/umbrel/umbrel/nodeblaster-identity/control-installation-id",
))
ENTITLEMENT_V2_BASE = os.environ.get(
    "NODEBLASTER_ENTITLEMENT_V2_BASE",
    "https://nodeblaster.com/updates/umbrel-nodeblaster/entitlement/v2",
).rstrip("/")
ENTITLEMENT_KEY_ID = os.environ.get("NODEBLASTER_ENTITLEMENT_KEY_ID", "entitlement-2026-01")
V2_ENTITLEMENT_TRUSTED_PUBLIC_KEY = """-----BEGIN PUBLIC KEY-----
MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEA4I3IXwMx1rJr4UfFmnAIOB7p59YUdNeM
zL0NPEqu1Y+hTxRCYa9NFxlOy82LsvzMySEfpyYBz/41ueuj2wfSE0LhVKcpramTzQbch5+wtUJJ
2FwjyoJr/ILmwtWcdnEJ0xyMiCS3/Q5B+6Iwpkxm3lUbiDU7xglzjVMDTd2ScXktPix4QP1XD0IA
1FP5zmwhApsbUQ9Ix74x6KLbuX1XoNkf3zNVrJzczkiTFw8DVy1P60jw5IO8gRJHbxMdOeyjXaOR
zkqgm24QDadKtvB9GCbY/mqfQtDmlq13m7SAT/PSxP+KUx+a57zUxPlEyiYNquJUVN/NYGhuJefQ
IIsZChBeK4C7HbYOBey/JberM+88YmbPmQk05YsJdNyiknFnEUiNlM7jMRkpXJrUNpWfXnL+UPdU
7rbO6PXkVUFVmJ9ItBZCtIGiEF1uJfxxu3+L2Y4SCFlp3dbuDfZ5tKfhL/dBoMECh0H/Tc0ONUp7
dTDXhRUOUywcHTi92Pq3z7EpAgMBAAE=
-----END PUBLIC KEY-----
"""
DISPLAY_SERVICE = "nodeblaster-display.service"
SUITE_ACTIVATION_SERVICE = "nodeblaster-suite-activate.service"
MAX_BODY_BYTES = 16 * 1024
APP_UID = int(os.environ.get("NODEBLASTER_CONTROL_APP_UID", "1000"))
APP_GID = int(os.environ.get("NODEBLASTER_CONTROL_APP_GID", "1000"))
DISPLAY_STYLES = {
    "shares",
    "dashboard",
    "gauges",
    "fleet",
    "slideshow",
    "carousel",
    "screensaver",
    "mesh",
    "orbit",
    "console",
}
FEATURE_ALIASES = {
    "display_controls": {"host.display", "suite"},
    "updates": {"updates.stable", "updates.stable-bch", "suite"},
}


class BridgeError(RuntimeError):
    status = 400


class Unauthorized(BridgeError):
    status = 401


class Forbidden(BridgeError):
    status = 403


class Unavailable(BridgeError):
    status = 503


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def write_json_atomic(path: Path, payload: dict[str, Any], mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.chmod(temp, mode)
    os.replace(temp, path)


def run_systemctl(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["systemctl", *args],
        text=True,
        capture_output=True,
        timeout=20,
        check=False,
    )


def service_state(unit: str) -> dict[str, str]:
    enabled = run_systemctl("is-enabled", unit)
    active = run_systemctl("is-active", unit)
    return {
        "enabled": (enabled.stdout or enabled.stderr).strip() or "unknown",
        "active": (active.stdout or active.stderr).strip() or "unknown",
    }


def file_timestamp(path: Path) -> str | None:
    try:
        return dt.datetime.fromtimestamp(path.stat().st_mtime, dt.timezone.utc).isoformat()
    except OSError:
        return None


def load_updater_module():
    if not UPDATER_PATH.is_file():
        raise Unavailable("NodeBlaster entitlement verifier is not installed")
    spec = importlib.util.spec_from_file_location("nodeblaster_control_updater", UPDATER_PATH)
    if spec is None or spec.loader is None:
        raise Unavailable("NodeBlaster entitlement verifier could not be loaded")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64url_decode(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def canonical_json(payload: dict[str, Any]) -> bytes:
    return json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")


def strict_json(raw: str) -> Any:
    def unique_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate key: {key}")
            result[key] = value
        return result

    return json.loads(raw, object_pairs_hook=unique_object)


def parse_time(value: object) -> dt.datetime:
    parsed = dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.timezone.utc)
    return parsed.astimezone(dt.timezone.utc)


def entitlement_v2_public_key() -> str:
    override = os.environ.get("NODEBLASTER_ENTITLEMENT_V2_TRUSTED_KEY", "").strip()
    if override:
        return Path(override).read_text(encoding="utf-8")
    return V2_ENTITLEMENT_TRUSTED_PUBLIC_KEY


def verify_v2_envelope(envelope: dict[str, Any]) -> dict[str, Any]:
    if envelope.get("schema") != 2:
        raise Forbidden("Entitlement response schema is invalid")
    if envelope.get("key_id") != ENTITLEMENT_KEY_ID:
        raise Forbidden("Entitlement signing key is not trusted")
    try:
        payload_bytes = b64url_decode(str(envelope["payload"]))
        signature = b64url_decode(str(envelope["signature"]))
        payload = strict_json(payload_bytes.decode("utf-8"))
    except Exception as error:
        raise Forbidden("Entitlement response is malformed") from error
    if not isinstance(payload, dict) or canonical_json(payload) != payload_bytes:
        raise Forbidden("Entitlement response is not canonical")
    with tempfile.TemporaryDirectory(prefix="nodeblaster-control-verify-") as tmp:
        root = Path(tmp)
        key = root / "trusted.pem"
        body = root / "payload.json"
        sig = root / "payload.sig"
        key.write_text(entitlement_v2_public_key(), encoding="utf-8")
        body.write_bytes(payload_bytes)
        sig.write_bytes(signature)
        result = subprocess.run(
            ["openssl", "dgst", "-sha256", "-verify", str(key), "-signature", str(sig), str(body)],
            text=True,
            capture_output=True,
            timeout=10,
            check=False,
        )
    if result.returncode != 0:
        raise Forbidden("Entitlement response signature is invalid")
    return payload


def installation_id() -> str:
    if INSTALLATION_ID_PATH.exists():
        value = INSTALLATION_ID_PATH.read_text(encoding="utf-8").strip()
        try:
            return str(uuid.UUID(value))
        except ValueError as error:
            raise Forbidden("Installation identity is invalid") from error
    INSTALLATION_ID_PATH.parent.mkdir(parents=True, exist_ok=True)
    value = str(uuid.uuid4())
    INSTALLATION_ID_PATH.write_text(value + "\n", encoding="utf-8")
    os.chmod(INSTALLATION_ID_PATH, 0o600)
    return value


def signed_device_request(extra: dict[str, Any], *, include_public_key: bool = True) -> dict[str, Any]:
    updater = load_updater_module()
    private_key, public_key = updater.ensure_entitlement_device_key()
    fingerprint = hashlib.sha256(public_key.encode("utf-8")).hexdigest()
    payload = {
        "schema": 2,
        "request_id": str(uuid.uuid4()),
        "sent_at": now_iso(),
        "nonce": secrets.token_hex(16),
        "installation_id": installation_id(),
        "key_fingerprint": fingerprint,
        "device_claim": updater.hardware_id(),
        **extra,
    }
    body = canonical_json(payload)
    request = {
        "payload": b64url(body),
        "signature": b64url(updater.sign_entitlement_payload(body, private_key)),
    }
    if include_public_key:
        request["public_key"] = public_key
    return request


def post_v2(path: str, request: dict[str, Any]) -> dict[str, Any]:
    body = canonical_json(request)
    http_request = urllib.request.Request(
        ENTITLEMENT_V2_BASE + path,
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "User-Agent": f"NodeBlasterControlBridge/{VERSION}",
            "Idempotency-Key": str(uuid.uuid4()),
        },
    )
    try:
        with urllib.request.urlopen(http_request, timeout=30) as response:
            raw = response.read(64 * 1024 + 1)
    except urllib.error.HTTPError as error:
        raw = error.read(64 * 1024 + 1)
        if not raw:
            raise Unavailable(f"Entitlement service returned HTTP {error.code}") from error
    except (urllib.error.URLError, TimeoutError, OSError) as error:
        raise Unavailable("Entitlement service is unavailable") from error
    if len(raw) > 64 * 1024:
        raise Forbidden("Entitlement response is too large")
    try:
        envelope = strict_json(raw.decode("utf-8"))
    except Exception as error:
        raise Forbidden("Entitlement service returned an unsigned response") from error
    if not isinstance(envelope, dict):
        raise Forbidden("Entitlement service returned an invalid response")
    return envelope


def validate_v2_lease(envelope: dict[str, Any]) -> dict[str, Any]:
    lease = verify_v2_envelope(envelope)
    if lease.get("schema") != 2 or lease.get("state") != "active":
        raise Forbidden("NodeBlaster Suite license is not active")
    required_text = {
        "lease_id", "entitlement_id", "activation_id", "installation_id",
        "key_fingerprint", "plan", "channel", "package_policy", "issued_at",
        "refresh_after", "expires_at", "offline_grace_until", "transfer_after",
    }
    if any(not isinstance(lease.get(field), str) or not str(lease[field]).strip() for field in required_text):
        raise Forbidden("License is missing required fields")
    for field in ("lease_id", "activation_id", "installation_id"):
        try:
            uuid.UUID(str(lease[field]))
        except ValueError as error:
            raise Forbidden(f"License {field} is invalid") from error
    entitlement_id = str(lease["entitlement_id"])
    if len(entitlement_id) != 36 or not entitlement_id.startswith("ent_") or any(
        character not in "0123456789abcdef" for character in entitlement_id[4:]
    ):
        raise Forbidden("License entitlement_id is invalid")
    if str(lease["installation_id"]) != installation_id():
        raise Forbidden("License belongs to another installation")
    updater = load_updater_module()
    _private_key, public_key = updater.ensure_entitlement_device_key()
    expected_fingerprint = hashlib.sha256(public_key.encode("utf-8")).hexdigest()
    if not hmac.compare_digest(str(lease["key_fingerprint"]), expected_fingerprint):
        raise Forbidden("License belongs to another device key")
    features = lease.get("features")
    if not isinstance(features, list) or not all(isinstance(feature, str) and feature for feature in features):
        raise Forbidden("License feature grants are invalid")
    if not isinstance(lease.get("policy_version"), int) or int(lease["policy_version"]) < 1:
        raise Forbidden("License policy version is invalid")
    try:
        issued_at = parse_time(lease["issued_at"])
        refresh_after = parse_time(lease["refresh_after"])
        expires_at = parse_time(lease["expires_at"])
        offline_grace_until = parse_time(lease["offline_grace_until"])
        parse_time(lease["transfer_after"])
    except Exception as error:
        raise Forbidden("License timing is invalid") from error
    if not issued_at < refresh_after <= expires_at <= offline_grace_until:
        raise Forbidden("License timing order is invalid")
    provisioning_version = lease.get("provisioning_version")
    if provisioning_version is not None:
        sealed = lease.get("sealed_configuration")
        if provisioning_version != 1 or not isinstance(sealed, dict):
            raise Forbidden("License provisioning data is invalid")
        ciphertext = sealed.get("discord_webhook")
        if sealed.get("schema") != 1 or sealed.get("cipher") != "RSA-OAEP" \
                or not isinstance(ciphertext, str) or not 1 <= len(ciphertext) <= 2048:
            raise Forbidden("License provisioning data is invalid")
    return lease


def provision_configuration(lease: dict[str, Any]) -> None:
    if lease.get("provisioning_version") != 1:
        return
    sealed = lease["sealed_configuration"]
    try:
        ciphertext = b64url_decode(str(sealed["discord_webhook"]))
    except Exception as error:
        raise Forbidden("License provisioning data is malformed") from error
    updater = load_updater_module()
    private_key, _public_key = updater.ensure_entitlement_device_key()
    result = subprocess.run(
        [
            "openssl", "pkeyutl", "-decrypt", "-inkey", str(private_key),
            "-pkeyopt", "rsa_padding_mode:oaep",
        ],
        input=ciphertext,
        capture_output=True,
        timeout=10,
        check=False,
    )
    if result.returncode != 0:
        raise Forbidden("Appliance configuration could not be decrypted")
    try:
        webhook = result.stdout.decode("utf-8").strip()
    except UnicodeDecodeError as error:
        raise Forbidden("Appliance configuration is invalid") from error
    parsed = urllib.parse.urlparse(webhook)
    allowed_hosts = {"discord.com", "www.discord.com", "discordapp.com", "www.discordapp.com"}
    if parsed.scheme != "https" or parsed.hostname not in allowed_hosts \
            or not re.fullmatch(r"/api/webhooks/[0-9]+/[A-Za-z0-9._-]+", parsed.path) \
            or parsed.query or parsed.fragment or len(webhook) > 512:
        raise Forbidden("Appliance configuration is invalid")
    DISCORD_WEBHOOK_PATH.parent.mkdir(parents=True, exist_ok=True)
    temp = DISCORD_WEBHOOK_PATH.with_suffix(DISCORD_WEBHOOK_PATH.suffix + ".tmp")
    temp.write_text(webhook + "\n", encoding="utf-8")
    os.chmod(temp, 0o600)
    os.replace(temp, DISCORD_WEBHOOK_PATH)


def invalidate_v2_lease(*, state: str, reason_code: str, server_time: object = None) -> None:
    CONTROL_LEASE_PATH.unlink(missing_ok=True)
    write_json_atomic(CONTROL_DENIAL_PATH, {
        "schema": 1,
        "state": state,
        "reason_code": reason_code,
        "server_time": server_time,
        "recorded_at": now_iso(),
    })


def refresh_v2_lease() -> dict[str, Any]:
    if not CONTROL_LEASE_PATH.is_file():
        raise Forbidden("NodeBlaster Suite is not activated")
    cached_envelope = read_json(CONTROL_LEASE_PATH)
    cached = validate_v2_lease(cached_envelope)
    request = signed_device_request({
        "activation_id": cached.get("activation_id"),
        "current_lease_id": cached.get("lease_id"),
    }, include_public_key=False)
    try:
        envelope = post_v2("/leases", request)
    except Unavailable:
        try:
            grace_until = parse_time(cached.get("offline_grace_until"))
        except Exception as error:
            raise Forbidden("Offline grace is unavailable") from error
        if grace_until <= dt.datetime.now(dt.timezone.utc):
            raise Forbidden("Offline grace has expired")
        return {**cached, "_lease_source": "offline_grace"}
    try:
        decision = verify_v2_envelope(envelope)
    except BridgeError:
        invalidate_v2_lease(state="invalid", reason_code="response_invalid")
        raise
    if decision.get("decision") == "deny":
        invalidate_v2_lease(
            state=str(decision.get("state") or "inactive"),
            reason_code=str(decision.get("reason_code") or "denied"),
            server_time=decision.get("server_time"),
        )
        raise Forbidden(f"License refresh denied: {decision.get('reason_code', 'unknown')}")
    refreshed = validate_v2_lease(envelope)
    provision_configuration(refreshed)
    write_json_atomic(CONTROL_LEASE_PATH, envelope)
    CONTROL_DENIAL_PATH.unlink(missing_ok=True)
    return {**refreshed, "_lease_source": "online"}


def verified_v2_lease() -> dict[str, Any]:
    if CONTROL_DENIAL_PATH.is_file():
        denial = read_json(CONTROL_DENIAL_PATH)
        raise Forbidden(f"License is blocked: {denial.get('reason_code', 'denied')}")
    if not CONTROL_LEASE_PATH.is_file():
        raise Forbidden("NodeBlaster Suite is not activated")
    envelope = read_json(CONTROL_LEASE_PATH)
    lease = validate_v2_lease(envelope)
    now = dt.datetime.now(dt.timezone.utc)
    try:
        refresh_after = parse_time(lease.get("refresh_after"))
        expires_at = parse_time(lease.get("expires_at"))
    except Exception as error:
        invalidate_v2_lease(state="invalid", reason_code="lease_time_invalid")
        raise Forbidden("License timing is invalid") from error
    if now >= refresh_after:
        return refresh_v2_lease()
    if expires_at <= now:
        raise Forbidden("Online license refresh is required")
    if lease.get("provisioning_version") == 1:
        provision_configuration(lease)
    elif not DISCORD_WEBHOOK_PATH.is_file():
        return refresh_v2_lease()
    return {**lease, "_lease_source": "cached"}


def verified_entitlement() -> dict[str, Any]:
    if CONTROL_LEASE_PATH.is_file():
        return verified_v2_lease()
    try:
        updater = load_updater_module()
        return updater.cached_entitlement_lease(updater.hardware_id())
    except Unavailable:
        raise
    except Exception as error:
        raise Forbidden(f"A valid NodeBlaster license is required: {error}") from error


def lease_allows(lease: dict[str, Any], feature: str) -> bool:
    if lease.get("schema") == 2:
        granted = {str(item) for item in lease.get("features", []) if isinstance(item, str)}
        return bool(granted & FEATURE_ALIASES.get(feature, {feature, "suite"}))
    entitlements = lease.get("entitlements")
    if entitlements is None:
        # Existing shipped-unit leases predate feature-level grants and represent
        # the complete appliance suite.
        return str(lease.get("status", "")) == "active"
    if isinstance(entitlements, dict):
        return bool(entitlements.get("suite") or entitlements.get(feature))
    if isinstance(entitlements, list):
        return "suite" in entitlements or feature in entitlements
    return False


class BridgeState:
    def __init__(
        self,
        entitlement_reader: Callable[[], dict[str, Any]] = verified_entitlement,
        command_runner: Callable[..., subprocess.CompletedProcess[str]] = run_systemctl,
    ) -> None:
        self.entitlement_reader = entitlement_reader
        self.command_runner = command_runner

    def license_status(self) -> dict[str, Any]:
        try:
            lease = self.entitlement_reader()
        except BridgeError as error:
            return {"state": "inactive", "message": str(error), "entitlements": []}
        entitlements = lease.get("features", lease.get("entitlements", ["suite"]))
        return {
            "state": "active",
            "expires_at": lease.get("expires_at"),
            "source": lease.get("_lease_source", "legacy"),
            "product_profile": lease.get("product_profile") or lease.get("plan"),
            "entitlements": entitlements,
        }

    def activate(self, payload: dict[str, Any]) -> dict[str, Any]:
        claim = str(payload.get("license_key") or "").strip()
        transfer = str(payload.get("transfer_grant") or "").strip()
        if bool(claim) == bool(transfer):
            raise BridgeError("Provide one license key or transfer grant")
        if max(len(claim), len(transfer)) > 256:
            raise BridgeError("Activation claim is too long")
        request = signed_device_request({
            "activation_claim_hash": hashlib.sha256((claim or transfer).encode("utf-8")).hexdigest(),
            "plan_hint": "nodeblaster-byo-standard",
            "agent_version": VERSION,
        })
        request.update({"license_key": claim} if claim else {"transfer_grant": transfer})
        envelope = post_v2("/activations", request)
        decision = verify_v2_envelope(envelope)
        if decision.get("decision") == "deny":
            CONTROL_LEASE_PATH.unlink(missing_ok=True)
            raise Forbidden(f"Activation denied: {decision.get('reason_code', 'unknown')}")
        validate_v2_lease(envelope)
        provision_configuration(decision)
        write_json_atomic(CONTROL_LEASE_PATH, envelope)
        CONTROL_DENIAL_PATH.unlink(missing_ok=True)
        return self.license_status()

    def require(self, feature: str) -> dict[str, Any]:
        lease = self.entitlement_reader()
        if not lease_allows(lease, feature):
            raise Forbidden(f"License does not include {feature}")
        return lease

    def display_status(self) -> dict[str, Any]:
        config = read_json(DISPLAY_CONFIG)
        style = str(config.get("style") or "fleet")
        if style not in DISPLAY_STYLES:
            style = "fleet"
        state = service_state(DISPLAY_SERVICE) if DISPLAY_SCRIPT.is_file() else {
            "enabled": "not-installed",
            "active": "not-installed",
        }
        return {
            "installed": DISPLAY_SCRIPT.is_file(),
            "style": style,
            "source": config.get("source", "default"),
            "service": state,
            "framebuffer_ready": Path("/dev/fb0").exists(),
        }

    def installation_status(self) -> dict[str, Any]:
        license_active = self.license_status().get("state") == "active"
        if not license_active:
            return {"state": "waiting", "stage": "Waiting for activation"}
        started_at = file_timestamp(CONTROL_LEASE_PATH)
        last_activity_at = max(
            (value for value in (started_at, file_timestamp(BRANDING_LOG_PATH)) if value),
            default=started_at,
        )
        if SUITE_INITIALIZED_MARKER.is_file():
            return {
                "state": "ready",
                "stage": "Installation complete",
                "started_at": started_at,
                "last_activity_at": last_activity_at,
                "completed_at": file_timestamp(SUITE_INITIALIZED_MARKER),
            }
        details = self.command_runner(
            "show",
            SUITE_ACTIVATION_SERVICE,
            "--property=ActiveState,SubState,Result",
            "--no-pager",
        )
        values = {}
        for line in details.stdout.splitlines():
            key, separator, value = line.partition("=")
            if separator:
                values[key] = value
        if values.get("ActiveState") in {"activating", "active"}:
            elapsed = max(0, int(time.time() - CONTROL_LEASE_PATH.stat().st_mtime)) if started_at else 0
            return {
                "state": "installing",
                "stage": "Applying backgrounds, services, and display features",
                "started_at": started_at,
                "last_activity_at": last_activity_at,
                "elapsed_seconds": elapsed,
            }
        if values.get("ActiveState") == "failed" or values.get("Result") not in {"", "success"}:
            return {
                "state": "failed",
                "stage": "Installation needs attention",
                "started_at": started_at,
                "last_activity_at": last_activity_at,
            }
        return {
            "state": "queued",
            "stage": "Activation accepted; installation is starting",
            "started_at": started_at,
            "last_activity_at": last_activity_at,
        }

    def set_display(self, payload: dict[str, Any]) -> dict[str, Any]:
        self.require("display_controls")
        style = str(payload.get("style") or "").strip().lower()
        if style not in DISPLAY_STYLES:
            raise BridgeError("Unsupported display style")
        if not DISPLAY_SCRIPT.is_file():
            raise Unavailable("NodeBlaster display service is not installed")
        write_json_atomic(DISPLAY_CONFIG, {
            "style": style,
            "source": "nodeblaster-control-app",
            "updated_at": now_iso(),
        })
        if style == "console":
            result = self.command_runner("disable", "--now", DISPLAY_SERVICE)
            if result.returncode == 0:
                restore = subprocess.run(
                    ["/usr/bin/python3", str(DISPLAY_SCRIPT), "--style", "console", "--restore-console"],
                    text=True,
                    capture_output=True,
                    timeout=10,
                    check=False,
                )
                result = restore if restore.returncode else result
        else:
            result = self.command_runner("enable", "--now", DISPLAY_SERVICE)
            if result.returncode == 0:
                result = self.command_runner("restart", DISPLAY_SERVICE)
        if result.returncode != 0:
            detail = (result.stderr or result.stdout or "display service command failed").strip()
            raise Unavailable(detail)
        return self.display_status()

    def status(self) -> dict[str, Any]:
        identity = read_json(IDENTITY_PATH)
        updater = read_json(UPDATER_STATUS)
        return {
            "ok": True,
            "bridge_version": VERSION,
            "unit": {
                "unit_id": identity.get("unit_id"),
                "product_profile": identity.get("product_profile"),
                "display_profile": identity.get("display_profile"),
            },
            "license": self.license_status(),
            "installation": self.installation_status(),
            "updater": {
                "result": updater.get("last_result"),
                "version": updater.get("current_version"),
                "display_version": updater.get("current_display_version"),
            },
            "display": self.display_status(),
        }


if hasattr(socketserver, "UnixStreamServer"):
    class UnixHTTPServer(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
        daemon_threads = True
else:
    class UnixHTTPServer:  # pragma: no cover - Windows import compatibility for tests
        def __init__(self, *_args: object, **_kwargs: object) -> None:
            raise OSError("Unix sockets are required")


class Handler(BaseHTTPRequestHandler):
    server_version = "NodeBlasterControlBridge/0.1"
    protocol_version = "HTTP/1.1"

    def log_message(self, format: str, *args: object) -> None:
        return

    @property
    def state(self) -> BridgeState:
        return self.server.state  # type: ignore[attr-defined]

    def authenticated(self) -> bool:
        expected = TOKEN_PATH.read_text(encoding="utf-8").strip()
        provided = self.headers.get("Authorization", "").removeprefix("Bearer ").strip()
        return bool(provided) and hmac.compare_digest(provided, expected)

    def payload(self) -> dict[str, Any]:
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError as error:
            raise BridgeError("Invalid content length") from error
        if size < 0 or size > MAX_BODY_BYTES:
            raise BridgeError("Request body is too large")
        if not size:
            return {}
        try:
            value = json.loads(self.rfile.read(size).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise BridgeError("Request body must be JSON") from error
        if not isinstance(value, dict):
            raise BridgeError("Request body must be an object")
        return value

    def respond(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def dispatch(self) -> None:
        if not self.authenticated():
            raise Unauthorized("Bridge authentication failed")
        if self.command == "GET" and self.path == "/v1/status":
            self.respond(200, self.state.status())
            return
        if self.command == "GET" and self.path == "/v1/display":
            self.respond(200, self.state.display_status())
            return
        if self.command == "PUT" and self.path == "/v1/display":
            self.respond(200, self.state.set_display(self.payload()))
            return
        if self.command == "POST" and self.path == "/v1/license/activate":
            self.respond(200, self.state.activate(self.payload()))
            return
        self.respond(404, {"ok": False, "error": "not_found"})

    def handle_request(self) -> None:
        try:
            self.dispatch()
        except BridgeError as error:
            self.respond(error.status, {"ok": False, "error": str(error)})
        except Exception:
            self.respond(500, {"ok": False, "error": "bridge_internal_error"})

    do_GET = handle_request
    do_PUT = handle_request
    do_POST = handle_request


def prepare_runtime() -> str:
    BRIDGE_DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(BRIDGE_DIR, 0o770)
    try:
        os.chown(BRIDGE_DIR, APP_UID, APP_GID)
    except PermissionError:
        pass
    if not TOKEN_PATH.exists():
        TOKEN_PATH.write_text(secrets.token_urlsafe(32) + "\n", encoding="utf-8")
    os.chmod(TOKEN_PATH, 0o640)
    try:
        os.chown(TOKEN_PATH, 0, APP_GID)
    except PermissionError:
        pass
    SOCKET_PATH.unlink(missing_ok=True)
    return TOKEN_PATH.read_text(encoding="utf-8").strip()


def main() -> int:
    prepare_runtime()
    server = UnixHTTPServer(str(SOCKET_PATH), Handler)
    server.state = BridgeState()  # type: ignore[attr-defined]
    os.chmod(SOCKET_PATH, 0o660)
    try:
        os.chown(SOCKET_PATH, 0, APP_GID)
    except PermissionError:
        pass
    try:
        server.serve_forever()
    finally:
        server.server_close()
        SOCKET_PATH.unlink(missing_ok=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
