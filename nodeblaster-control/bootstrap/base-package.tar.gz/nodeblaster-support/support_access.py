#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import pwd
import shutil
import socket
import subprocess
from pathlib import Path
from typing import Any


SUPPORT_DIR = Path("/home/umbrel/umbrel/nodeblaster-support")
STATE_PATH = SUPPORT_DIR / "support-state.json"
EVENTS_PATH = SUPPORT_DIR / "support-events.jsonl"
PUBLIC_KEY_PATH = SUPPORT_DIR / "keys" / "nodeblaster-support.pub"
AUTHORIZED_KEYS = Path("/home/nodeblaster-support/.ssh/authorized_keys")
SUDOERS_PATH = Path("/etc/sudoers.d/nodeblaster-support")
SUPPORT_USER = "nodeblaster-support"
DEFAULT_DURATION_MINUTES = 120
DEFAULT_FROM = "100.64.0.0/10,fd7a:115c:a1e0::/48"
TAILSCALE_BIN_CANDIDATES = (
    "tailscale",
    "/usr/bin/tailscale",
    "/usr/sbin/tailscale",
    "/usr/local/bin/tailscale",
    "/usr/local/sbin/tailscale",
)
TAILSCALE_WEB_PORT = 8240


def now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def now_iso() -> str:
    return now().astimezone().isoformat(timespec="seconds")


def parse_time(value: str | None) -> dt.datetime | None:
    if not value:
        return None
    try:
        return dt.datetime.fromisoformat(value)
    except ValueError:
        return None


def run(command: list[str], *, check: bool = False) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, text=True, capture_output=True)
    if check and result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()
        raise RuntimeError(f"{command!r} failed with {result.returncode}: {detail}")
    return result


def resolve_executable(candidates: tuple[str, ...]) -> str | None:
    for candidate in candidates:
        resolved = shutil.which(candidate)
        if resolved:
            return resolved
        path = Path(candidate)
        if path.is_absolute() and path.exists() and os.access(path, os.X_OK):
            return str(path)
    return None


def local_port_open(port: int) -> bool:
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=1):
            return True
    except OSError:
        return False


def write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def read_state() -> dict[str, Any]:
    if not STATE_PATH.exists():
        return {"enabled": False, "support_user": SUPPORT_USER}
    try:
        state = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        if isinstance(state, dict):
            return state
    except Exception:
        pass
    return {"enabled": False, "support_user": SUPPORT_USER, "state_error": "could-not-read-state"}


def append_event(event: str, detail: dict[str, Any] | None = None) -> None:
    SUPPORT_DIR.mkdir(parents=True, exist_ok=True)
    entry = {
        "at": now_iso(),
        "event": event,
        "support_user": SUPPORT_USER,
        **(detail or {}),
    }
    with EVENTS_PATH.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, sort_keys=True) + "\n")


def tailscale_status() -> dict[str, Any]:
    tailscale_bin = resolve_executable(TAILSCALE_BIN_CANDIDATES)
    if not tailscale_bin:
        web_client = local_port_open(TAILSCALE_WEB_PORT)
        return {
            "installed": web_client,
            "running": web_client,
            "online": web_client,
            "web_client": web_client,
        }
    status = run([tailscale_bin, "status", "--json"])
    info: dict[str, Any] = {"installed": True, "running": status.returncode == 0}
    if status.returncode != 0:
        info["error"] = (status.stderr or status.stdout or "").strip()
        return info
    try:
        parsed = json.loads(status.stdout)
    except json.JSONDecodeError:
        info["error"] = "could-not-parse-tailscale-status"
        return info
    self_info = parsed.get("Self") or {}
    info["hostname"] = self_info.get("HostName")
    info["dns_name"] = self_info.get("DNSName")
    info["tailscale_ips"] = self_info.get("TailscaleIPs") or []
    info["online"] = bool(self_info.get("Online"))
    return info


def ensure_root() -> None:
    if os.geteuid() != 0:
        raise RuntimeError("support access changes must run as root")


def ensure_support_user() -> None:
    try:
        pwd.getpwnam(SUPPORT_USER)
    except KeyError:
        run(
            [
                "useradd",
                "--system",
                "--create-home",
                "--shell",
                "/bin/bash",
                "--comment",
                "NodeBlaster temporary support user",
                SUPPORT_USER,
            ],
            check=True,
        )
    run(["passwd", "-l", SUPPORT_USER], check=False)
    home = Path("/home") / SUPPORT_USER
    ssh_dir = home / ".ssh"
    ssh_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    shutil.chown(ssh_dir, user=SUPPORT_USER, group=SUPPORT_USER)


def public_key_line(from_restriction: str) -> str:
    if not PUBLIC_KEY_PATH.exists():
        raise RuntimeError(f"missing support public key: {PUBLIC_KEY_PATH}")
    key = PUBLIC_KEY_PATH.read_text(encoding="utf-8").strip()
    if not key.startswith(("ssh-ed25519 ", "sk-ssh-ed25519@", "ecdsa-sha2-", "ssh-rsa ")):
        raise RuntimeError(f"unsupported or invalid SSH public key in {PUBLIC_KEY_PATH}")
    options = [
        f'from="{from_restriction}"',
        "no-agent-forwarding",
        "no-X11-forwarding",
        "no-port-forwarding",
    ]
    return ",".join(options) + " " + key + "\n"


def write_authorized_key(from_restriction: str) -> None:
    AUTHORIZED_KEYS.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    AUTHORIZED_KEYS.write_text(public_key_line(from_restriction), encoding="utf-8")
    os.chmod(AUTHORIZED_KEYS, 0o600)
    shutil.chown(AUTHORIZED_KEYS.parent, user=SUPPORT_USER, group=SUPPORT_USER)
    shutil.chown(AUTHORIZED_KEYS, user=SUPPORT_USER, group=SUPPORT_USER)


def remove_authorized_key() -> None:
    if AUTHORIZED_KEYS.exists():
        AUTHORIZED_KEYS.unlink()


def write_sudoers() -> None:
    SUDOERS_PATH.write_text(
        f"{SUPPORT_USER} ALL=(root) NOPASSWD: /usr/bin/systemctl, /usr/bin/journalctl, /usr/bin/python3, /usr/bin/tailscale, /usr/bin/cat, /usr/bin/tail, /usr/bin/grep, /usr/bin/ls\n",
        encoding="utf-8",
    )
    os.chmod(SUDOERS_PATH, 0o440)
    check = run(["visudo", "-cf", str(SUDOERS_PATH)])
    if check.returncode != 0:
        SUDOERS_PATH.unlink(missing_ok=True)
        raise RuntimeError((check.stderr or check.stdout or "sudoers validation failed").strip())


def remove_sudoers() -> None:
    SUDOERS_PATH.unlink(missing_ok=True)


def enable(minutes: int, from_restriction: str) -> dict[str, Any]:
    ensure_root()
    ensure_support_user()
    write_authorized_key(from_restriction)
    write_sudoers()
    expires_at = (now() + dt.timedelta(minutes=minutes)).astimezone().isoformat(timespec="seconds")
    state = {
        "enabled": True,
        "enabled_at": now_iso(),
        "expires_at": expires_at,
        "support_user": SUPPORT_USER,
        "ssh_public_key": str(PUBLIC_KEY_PATH),
        "ssh_from": from_restriction,
        "tailscale": tailscale_status(),
    }
    write_json(STATE_PATH, state)
    append_event("enabled", {"expires_at": expires_at, "ssh_from": from_restriction})
    return state


def disable(reason: str = "manual") -> dict[str, Any]:
    ensure_root()
    remove_authorized_key()
    remove_sudoers()
    state = read_state()
    state.update(
        {
            "enabled": False,
            "disabled_at": now_iso(),
            "disable_reason": reason,
            "support_user": SUPPORT_USER,
            "tailscale": tailscale_status(),
        }
    )
    write_json(STATE_PATH, state)
    append_event("disabled", {"reason": reason})
    return state


def expire() -> dict[str, Any]:
    state = read_state()
    expires = parse_time(str(state.get("expires_at") or ""))
    if state.get("enabled") and expires and now() >= expires.astimezone(dt.timezone.utc):
        return disable("expired")
    return status()


def status() -> dict[str, Any]:
    state = read_state()
    expires = parse_time(str(state.get("expires_at") or ""))
    expired = bool(state.get("enabled") and expires and now() >= expires.astimezone(dt.timezone.utc))
    active_key = AUTHORIZED_KEYS.exists()
    state.update(
        {
            "enabled": bool(state.get("enabled")) and not expired and active_key,
            "expired": expired,
            "authorized_key_present": active_key,
            "sudoers_present": SUDOERS_PATH.exists(),
            "support_user": SUPPORT_USER,
            "tailscale": tailscale_status(),
            "checked_at": now_iso(),
        }
    )
    return state


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Manage temporary NodeBlaster SSH support access.")
    sub = parser.add_subparsers(dest="command", required=True)
    enable_parser = sub.add_parser("enable")
    enable_parser.add_argument("--minutes", type=int, default=DEFAULT_DURATION_MINUTES)
    enable_parser.add_argument("--from", dest="from_restriction", default=DEFAULT_FROM)
    sub.add_parser("disable")
    sub.add_parser("expire")
    sub.add_parser("status")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        if args.command == "enable":
            result = enable(max(5, min(args.minutes, 24 * 60)), args.from_restriction)
        elif args.command == "disable":
            result = disable()
        elif args.command == "expire":
            result = expire()
        else:
            result = status()
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0
    except Exception as error:
        print(json.dumps({"error": str(error), "checked_at": now_iso()}, indent=2, sort_keys=True))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
