#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import datetime as dt
import fcntl
import hashlib
import html
import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import tarfile
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any


VERSION = "2026.07.25-entitlement-bootstrap-v1"
DEFAULT_MANIFEST_URL = "https://nodeblaster.com/updates/umbrel-nodeblaster/stable/manifest.json"
DEFAULT_ENTITLEMENT_URL = "https://nodeblaster.com/updates/umbrel-nodeblaster/entitlement/lease.php"
DEFAULT_PRODUCT_PROFILE = "core"
BCH_PRODUCT_PROFILES = {"mecha", "pro", "bithunter"}
PRODUCT_PROFILE_ALIASES = {
    "core+": "core-plus",
    "coreplus": "core-plus",
}
STATE_DIR = Path("/home/umbrel/umbrel/nodeblaster-updater")
LOG_PATH = STATE_DIR / "update.log"
CURRENT_VERSION_PATH = STATE_DIR / "current-version"
CURRENT_DISPLAY_VERSION_PATH = STATE_DIR / "current-display-version"
HISTORY_PATH = STATE_DIR / "version-history.jsonl"
STATUS_JSON_PATH = STATE_DIR / "status.json"
STATUS_HTML_PATH = STATE_DIR / "status.html"
TRUSTED_KEY_PATH = STATE_DIR / "trusted-release-key.pem"
MANIFEST_URL_PATH = STATE_DIR / "manifest-url"
PRODUCT_PROFILE_PATH = STATE_DIR / "product-profile"
HASHWATCHER_ALLOW_PATH = Path("/home/umbrel/umbrel/nodeblaster-security/hashwatcher-firewall.allow")
IDENTITY_DIR = Path("/home/umbrel/umbrel/nodeblaster-identity")
IDENTITY_PATH = IDENTITY_DIR / "unit.json"
ENTITLEMENT_MARKER_PATH = STATE_DIR / "entitlement-enforced"
ENTITLEMENT_LEASE_PATH = STATE_DIR / "entitlement-lease.json"
ENTITLEMENT_DEVICE_KEY_PATH = IDENTITY_DIR / "entitlement-device-key.pem"
ENTITLEMENT_DEVICE_PUBLIC_KEY_PATH = IDENTITY_DIR / "entitlement-device-public.pem"
ENTITLEMENT_REGISTRATION_TOKEN_PATH = IDENTITY_DIR / "registration-token"
LOCK_PATH = Path("/run/nodeblaster-updater.lock")
MAX_DOWNLOAD_BYTES = 80 * 1024 * 1024
ENTITLEMENT_MAX_RESPONSE_BYTES = 64 * 1024
ENTITLEMENT_MARKER_PACKAGE_PATH = "nodeblaster-updater/entitlement-enforced"
DMI_ID_PATHS = {
    "product_uuid": Path("/sys/class/dmi/id/product_uuid"),
    "board_serial": Path("/sys/class/dmi/id/board_serial"),
    "chassis_serial": Path("/sys/class/dmi/id/chassis_serial"),
}
ENTITLEMENT_TRUSTED_PUBLIC_KEY = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA4aYetcivdj7Tz5eZ/xYp
uAyUxbG7rk7W5KrwcpJt9RJxcSjMj2Kc5WSpWpgu149SAqDHjxPPmTMaSlKQcpvP
Z8rRlTwCEfGzUMG6DxK61xa71mltZ2GqfEfVAp61BkLwS2zI1XYzGSOj+k1GL5o0
OREmZJMlT+GbfoMl/hHsEkt7+gOYS3mFRZMfojsoieVvpmxiv4lMHauUTwvcQ4f0
nHR0mESJz7Yv+OG9MJcc1OwfkUlbg0uAoi5WyM9fF8sY2T3KK6PAGGnHWCaBpzaB
2q84Nm+FfVIhunKIfnP6Tt7cMDj0N0N45lBhT9kg1N4fb4eIz51Xby1EezQNys8f
gwIDAQAB
-----END PUBLIC KEY-----
"""


class RepositoryUnavailable(RuntimeError):
    pass


class EntitlementDenied(RuntimeError):
    pass


ALLOWED_FILES = {
    "nodeblaster-control-bridge/bridge.py": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-control-bridge/bridge.py"),
        "mode": 0o755,
    },
    "systemd/nodeblaster-control-bridge.service": {
        "target": Path("/etc/systemd/system/nodeblaster-control-bridge.service"),
        "mode": 0o644,
    },
    "nodeblaster-status/status_server.py": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-status/status_server.py"),
        "mode": 0o755,
    },
    "systemd/nodeblaster-status.service": {
        "target": Path("/etc/systemd/system/nodeblaster-status.service"),
        "mode": 0o644,
    },
    "custom-wallpapers/replace-existing-wallpapers.py": {
        "target": Path("/home/umbrel/umbrel/custom-wallpapers/replace-existing-wallpapers.py"),
        "mode": 0o755,
    },
    **{
        f"custom-wallpapers/source/slot-{slot:02d}.jpg": {
            "target": Path(f"/home/umbrel/umbrel/custom-wallpapers/source/slot-{slot:02d}.jpg"),
            "mode": 0o644,
        }
        for slot in range(1, 13)
    },
    "nodeblaster-updater/update.py": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-updater/update.py"),
        "mode": 0o755,
    },
    "nodeblaster-updater/trusted-firmware-key.pem": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-updater/trusted-firmware-key.pem"),
        "mode": 0o644,
    },
    ENTITLEMENT_MARKER_PACKAGE_PATH: {
        "target": ENTITLEMENT_MARKER_PATH,
        "mode": 0o600,
    },
    "systemd/nodeblaster-updater.service": {
        "target": Path("/etc/systemd/system/nodeblaster-updater.service"),
        "mode": 0o644,
    },
    "systemd/nodeblaster-updater.timer": {
        "target": Path("/etc/systemd/system/nodeblaster-updater.timer"),
        "mode": 0o644,
    },
    "nodeblaster-branding/apply.py": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-branding/apply.py"),
        "mode": 0o755,
    },
    "nodeblaster-branding/pre-start": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-branding/pre-start"),
        "mode": 0o755,
    },
    "custom-hooks/pre-start": {
        "target": Path("/home/umbrel/umbrel/custom-hooks/pre-start"),
        "mode": 0o755,
    },
    "systemd/nodeblaster-branding.service": {
        "target": Path("/etc/systemd/system/nodeblaster-branding.service"),
        "mode": 0o644,
    },
    "systemd/nodeblaster-branding.timer": {
        "target": Path("/etc/systemd/system/nodeblaster-branding.timer"),
        "mode": 0o644,
    },
    "nodeblaster-community-store/umbrel-app-store.yml": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-community-store/umbrel-app-store.yml"),
        "mode": 0o644,
    },
    "nodeblaster-community-store/nodeblaster-blockchair-bch-mempool/umbrel-app.yml": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-community-store/nodeblaster-blockchair-bch-mempool/umbrel-app.yml"),
        "mode": 0o644,
    },
    "nodeblaster-community-store/nodeblaster-blockchair-bch-mempool/icon.svg": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-community-store/nodeblaster-blockchair-bch-mempool/icon.svg"),
        "mode": 0o644,
    },
    "nodeblaster-community-store/nodeblaster-blockchair-bch-mempool/docker-compose.yml": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-community-store/nodeblaster-blockchair-bch-mempool/docker-compose.yml"),
        "mode": 0o644,
    },
    "nodeblaster-community-store/nodeblaster-blockchair-bch-mempool/nginx.conf": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-community-store/nodeblaster-blockchair-bch-mempool/nginx.conf"),
        "mode": 0o644,
    },
    "nodeblaster-updater/apps/nodeblaster-miner-widget/umbrel-app.yml": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-updater/apps/nodeblaster-miner-widget/umbrel-app.yml"),
        "mode": 0o644,
    },
    "nodeblaster-updater/apps/nodeblaster-miner-widget/docker-compose.yml": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-updater/apps/nodeblaster-miner-widget/docker-compose.yml"),
        "mode": 0o644,
    },
    "nodeblaster-updater/apps/nodeblaster-miner-widget/nginx.conf": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-updater/apps/nodeblaster-miner-widget/nginx.conf"),
        "mode": 0o644,
    },
    "nodeblaster-updater/apps/nodeblaster-miner-widget/nodeblaster-miner-widget-icon.png": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-updater/apps/nodeblaster-miner-widget/nodeblaster-miner-widget-icon.png"),
        "mode": 0o644,
    },
    "nodeblaster-tools/check-umbrel-app-port-conflicts.py": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-tools/check-umbrel-app-port-conflicts.py"),
        "mode": 0o755,
    },
    "nodeblaster-support/support_access.py": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-support/support_access.py"),
        "mode": 0o755,
    },
    "nodeblaster-display/display.py": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-display/display.py"),
        "mode": 0o755,
    },
    "nodeblaster-display/assets/logo-badge-v2.png": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-display/assets/logo-badge-v2.png"),
        "mode": 0o644,
    },
    "nodeblaster-display/assets/block-found-notification.png": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-display/assets/block-found-notification.png"),
        "mode": 0o644,
    },
    "nodeblaster-display/assets/block-found-alert.wav": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-display/assets/block-found-alert.wav"),
        "mode": 0o644,
    },
    "systemd/nodeblaster-display.service": {
        "target": Path("/etc/systemd/system/nodeblaster-display.service"),
        "mode": 0o644,
    },
    "systemd/nodeblaster-support-expire.service": {
        "target": Path("/etc/systemd/system/nodeblaster-support-expire.service"),
        "mode": 0o644,
    },
    "systemd/nodeblaster-support-expire.timer": {
        "target": Path("/etc/systemd/system/nodeblaster-support-expire.timer"),
        "mode": 0o644,
    },
    "nodeblaster-security/apply-hashwatcher-firewall.sh": {
        "target": Path("/home/umbrel/umbrel/nodeblaster-security/apply-hashwatcher-firewall.sh"),
        "mode": 0o755,
    },
    "systemd/nodeblaster-hashwatcher-firewall.service": {
        "target": Path("/etc/systemd/system/nodeblaster-hashwatcher-firewall.service"),
        "mode": 0o644,
    },
    "systemd/nodeblaster-hashwatcher-firewall.timer": {
        "target": Path("/etc/systemd/system/nodeblaster-hashwatcher-firewall.timer"),
        "mode": 0o644,
    },
}
SYSTEMD_UNITS = {
    Path("/etc/systemd/system/nodeblaster-control-bridge.service"): """[Unit]
Description=NodeBlaster licensed control bridge
After=umbrel.service nodeblaster-status.service
Wants=umbrel.service

[Service]
Type=simple
User=root
Group=root
UMask=0007
ExecStart=/usr/bin/python3 /home/umbrel/umbrel/nodeblaster-control-bridge/bridge.py
Restart=on-failure
RestartSec=5
PrivateTmp=true
ProtectSystem=full
ProtectHome=read-only
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
NoNewPrivileges=true
RestrictSUIDSGID=true
RestrictAddressFamilies=AF_UNIX AF_INET AF_INET6
ReadWritePaths=-/home/umbrel/umbrel/app-data/nodeblaster-control/data -/home/umbrel/umbrel/nodeblaster-display -/home/umbrel/umbrel/nodeblaster-identity

[Install]
WantedBy=multi-user.target
""",
    Path("/etc/systemd/system/nodeblaster-status.service"): """[Unit]
Description=NodeBlaster local update status service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 /home/umbrel/umbrel/nodeblaster-status/status_server.py
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
""",
    Path("/etc/systemd/system/nodeblaster-updater.service"): """[Unit]
Description=Check for signed NodeBlaster unit updates
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/bin/python3 /home/umbrel/umbrel/nodeblaster-updater/update.py
TimeoutStartSec=5min
Nice=10
IOSchedulingClass=idle

[Install]
WantedBy=multi-user.target
""",
    Path("/etc/systemd/system/nodeblaster-updater.timer"): """[Unit]
Description=Check for NodeBlaster unit updates twice daily

[Timer]
OnBootSec=20min
OnUnitActiveSec=12h
RandomizedDelaySec=45min
Persistent=true

[Install]
WantedBy=timers.target
""",
    Path("/etc/systemd/system/nodeblaster-branding.service"): """[Unit]
Description=Apply NodeBlaster Umbrel branding
After=local-fs.target network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/bin/python3 /home/umbrel/umbrel/nodeblaster-branding/apply.py --mode identity
TimeoutStartSec=2min
Nice=10
IOSchedulingClass=idle

[Install]
WantedBy=multi-user.target
""",
    Path("/etc/systemd/system/nodeblaster-branding.timer"): """[Unit]
Description=Periodically reapply NodeBlaster Umbrel branding

[Timer]
OnBootSec=10min
OnUnitActiveSec=6h
Persistent=true

[Install]
WantedBy=timers.target
""",
    Path("/etc/systemd/system/nodeblaster-support-expire.service"): """[Unit]
Description=Expire temporary NodeBlaster support SSH access
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/bin/python3 /home/umbrel/umbrel/nodeblaster-support/support_access.py expire
Nice=10
IOSchedulingClass=idle
""",
    Path("/etc/systemd/system/nodeblaster-support-expire.timer"): """[Unit]
Description=Check NodeBlaster support SSH access expiry

[Timer]
OnBootSec=2min
OnUnitActiveSec=5min
Persistent=true

[Install]
WantedBy=timers.target
""",
    Path("/etc/systemd/system/nodeblaster-display.service"): """[Unit]
Description=NodeBlaster local display animation
After=local-fs.target
ConditionPathExists=/dev/fb0

[Service]
Type=simple
ExecStart=/usr/bin/python3 /home/umbrel/umbrel/nodeblaster-display/display.py --duration 0 --style config --fps 10 --metric-refresh 10
ExecStopPost=/usr/bin/python3 /home/umbrel/umbrel/nodeblaster-display/display.py --style config --restore-console-if-config-console
Restart=on-failure
RestartSec=5
Nice=15
CPUWeight=20
CPUQuota=50%
IOSchedulingClass=idle

[Install]
WantedBy=multi-user.target
""",
    Path("/etc/systemd/system/nodeblaster-hashwatcher-firewall.service"): """[Unit]
Description=Restrict HashWatcher LAN API exposure
After=docker.service network-online.target
Wants=docker.service network-online.target
Before=umbrel.service

[Service]
Type=oneshot
ExecStart=/home/umbrel/umbrel/nodeblaster-security/apply-hashwatcher-firewall.sh apply

[Install]
WantedBy=multi-user.target
""",
    Path("/etc/systemd/system/nodeblaster-hashwatcher-firewall.timer"): """[Unit]
Description=Reapply HashWatcher firewall policy

[Timer]
OnBootSec=30s
OnUnitActiveSec=5min
Persistent=true
Unit=nodeblaster-hashwatcher-firewall.service

[Install]
WantedBy=timers.target
""",
}

UPDATE_PROCESS_KEYWORDS = (
    "umbrel-update",
    "umbrel update",
    "umbrel-updater",
    "umbreld update",
    "apt ",
    "apt-get",
    "apt.systemd.daily",
    "dpkg",
    "unattended-upgrade",
)
UPDATE_SERVICE_ACTIONS = ("update", "upgrade")


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).astimezone().isoformat(timespec="seconds")


def log(message: str) -> None:
    line = f"[{now_iso()}] {message}"
    try:
        STATE_DIR.mkdir(parents=True, exist_ok=True)
        with LOG_PATH.open("a", encoding="utf-8") as handle:
            handle.write(line + "\n")
    except Exception:
        print(line)


def run(
    command: list[str],
    *,
    check: bool = False,
    log_output: bool = True,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, text=True, capture_output=True, env=env)
    if log_output and result.stdout.strip():
        log(f"{command[0]} stdout: {result.stdout.strip()}")
    if log_output and result.stderr.strip():
        log(f"{command[0]} stderr: {result.stderr.strip()}")
    if check and result.returncode != 0:
        raise RuntimeError(f"{command!r} failed with {result.returncode}")
    return result


def acquire_lock():
    LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    handle = LOCK_PATH.open("w", encoding="utf-8")
    try:
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        log("Another NodeBlaster updater run is already active; skipping")
        handle.close()
        return None
    handle.write(f"{os.getpid()}\n")
    handle.flush()
    return handle


def update_activity_reason() -> str | None:
    if shutil.which("systemctl"):
        services = run(
            [
                "systemctl",
                "list-units",
                "--type=service",
                "--state=activating,active,running",
                "--no-legend",
                "--no-pager",
            ],
            log_output=False,
        )
        for line in services.stdout.splitlines():
            lower = line.lower()
            if "umbrel" in lower and any(action in lower for action in UPDATE_SERVICE_ACTIONS):
                return f"active update-related service: {line.strip()}"

    processes = run(["ps", "-eo", "pid=,comm=,args="], log_output=False)
    for line in processes.stdout.splitlines():
        lower = line.lower()
        if "nodeblaster-updater" in lower or "nodeblaster-branding" in lower:
            continue
        if any(keyword in lower for keyword in UPDATE_PROCESS_KEYWORDS):
            return f"active update-related process: {line.strip()}"
    return None


def read_url(url: str, max_bytes: int = MAX_DOWNLOAD_BYTES) -> bytes:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": f"Mozilla/5.0 NodeBlasterUpdater/{VERSION}"},
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            data = response.read(max_bytes + 1)
    except urllib.error.HTTPError as error:
        if error.code in {408, 429, 500, 502, 503, 504}:
            raise RepositoryUnavailable(f"Update repository unreachable: HTTP {error.code} for {url}") from error
        raise
    except (urllib.error.URLError, TimeoutError, socket.timeout, ConnectionError, OSError) as error:
        raise RepositoryUnavailable(f"Update repository unreachable: {url}") from error
    if len(data) > max_bytes:
        raise RuntimeError(f"Download exceeded {max_bytes} bytes: {url}")
    return data


def b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def b64url_decode(value: str) -> bytes:
    padding = "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode((value + padding).encode("ascii"))


def entitlement_url() -> str:
    env_url = os.environ.get("NODEBLASTER_ENTITLEMENT_URL", "").strip()
    if env_url:
        return env_url
    identity_url = str(unit_identity().get("entitlement_url", "")).strip()
    return identity_url or DEFAULT_ENTITLEMENT_URL


def hardware_id() -> str:
    invalid = {"", "none", "not specified", "not applicable", "default string", "unknown"}
    values: list[str] = []
    for label, path in DMI_ID_PATHS.items():
        try:
            value = path.read_text(encoding="utf-8", errors="replace").strip().lower()
        except OSError:
            continue
        if value not in invalid and not set(value) <= {"0", "-", " "}:
            values.append(f"{label}={value}")
    if not any(item.startswith("product_uuid=") for item in values):
        raise EntitlementDenied("hardware identity unavailable: product UUID is missing")
    material = "nodeblaster-hardware-v1\0" + "\0".join(values)
    return hashlib.sha256(material.encode("utf-8")).hexdigest()


def ensure_entitlement_device_key() -> tuple[Path, str]:
    IDENTITY_DIR.mkdir(parents=True, exist_ok=True)
    if not ENTITLEMENT_DEVICE_KEY_PATH.exists():
        if not shutil.which("openssl"):
            raise EntitlementDenied("openssl is required to create the entitlement device key")
        run(
            [
                "openssl",
                "genpkey",
                "-algorithm",
                "RSA",
                "-pkeyopt",
                "rsa_keygen_bits:2048",
                "-out",
                str(ENTITLEMENT_DEVICE_KEY_PATH),
            ],
            check=True,
            log_output=False,
        )
        os.chmod(ENTITLEMENT_DEVICE_KEY_PATH, 0o600)
    if not ENTITLEMENT_DEVICE_PUBLIC_KEY_PATH.exists():
        result = run(
            [
                "openssl",
                "pkey",
                "-in",
                str(ENTITLEMENT_DEVICE_KEY_PATH),
                "-pubout",
            ],
            check=True,
            log_output=False,
        )
        ENTITLEMENT_DEVICE_PUBLIC_KEY_PATH.write_text(result.stdout, encoding="utf-8")
        os.chmod(ENTITLEMENT_DEVICE_PUBLIC_KEY_PATH, 0o644)
    public_key = ENTITLEMENT_DEVICE_PUBLIC_KEY_PATH.read_text(encoding="utf-8").replace("\r\n", "\n")
    return ENTITLEMENT_DEVICE_KEY_PATH, public_key


def sign_entitlement_payload(payload: bytes, private_key_path: Path) -> bytes:
    if not shutil.which("openssl"):
        raise EntitlementDenied("openssl is required for entitlement verification")
    with tempfile.TemporaryDirectory(prefix="nodeblaster-entitlement-sign-") as tmp:
        payload_path = Path(tmp) / "request.json"
        signature_path = Path(tmp) / "request.sig"
        payload_path.write_bytes(payload)
        run(
            [
                "openssl",
                "dgst",
                "-sha256",
                "-sign",
                str(private_key_path),
                "-out",
                str(signature_path),
                str(payload_path),
            ],
            check=True,
            log_output=False,
        )
        return signature_path.read_bytes()


def post_entitlement_request(url: str, body: dict[str, Any]) -> dict[str, Any]:
    data = json.dumps(body, separators=(",", ":"), sort_keys=True).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=data,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "User-Agent": f"Mozilla/5.0 NodeBlasterUpdater/{VERSION}",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            raw = response.read(ENTITLEMENT_MAX_RESPONSE_BYTES + 1)
    except urllib.error.HTTPError as error:
        if error.code in {400, 401, 403, 409, 422}:
            try:
                detail = json.loads(error.read(ENTITLEMENT_MAX_RESPONSE_BYTES).decode("utf-8"))
                reason = str(detail.get("error") or "registration denied")
            except Exception:
                reason = "registration denied"
            raise EntitlementDenied(reason) from error
        if error.code in {408, 429, 500, 502, 503, 504}:
            raise RepositoryUnavailable(f"Entitlement service unreachable: HTTP {error.code}") from error
        raise
    except (urllib.error.URLError, TimeoutError, socket.timeout, ConnectionError, OSError) as error:
        raise RepositoryUnavailable("Entitlement service unreachable") from error
    if len(raw) > ENTITLEMENT_MAX_RESPONSE_BYTES:
        raise EntitlementDenied("entitlement response exceeded the size limit")
    result = json.loads(raw.decode("utf-8"))
    if not isinstance(result, dict):
        raise EntitlementDenied("invalid entitlement response")
    return result


def entitlement_public_key() -> str:
    override = os.environ.get("NODEBLASTER_ENTITLEMENT_TRUSTED_KEY", "").strip()
    if override:
        return Path(override).read_text(encoding="utf-8")
    return ENTITLEMENT_TRUSTED_PUBLIC_KEY


def parse_utc(value: str) -> dt.datetime:
    parsed = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.timezone.utc)
    return parsed.astimezone(dt.timezone.utc)


def verify_entitlement_lease(response: dict[str, Any], expected_hardware_id: str) -> dict[str, Any]:
    try:
        payload_bytes = b64url_decode(str(response["payload"]))
        signature = b64url_decode(str(response["signature"]))
        lease = json.loads(payload_bytes.decode("utf-8"))
    except Exception as error:
        raise EntitlementDenied("invalid signed entitlement lease") from error
    if not isinstance(lease, dict):
        raise EntitlementDenied("invalid entitlement lease payload")
    with tempfile.TemporaryDirectory(prefix="nodeblaster-entitlement-verify-") as tmp:
        public_key_path = Path(tmp) / "trusted-key.pem"
        payload_path = Path(tmp) / "lease.json"
        signature_path = Path(tmp) / "lease.sig"
        public_key_path.write_text(entitlement_public_key(), encoding="utf-8")
        payload_path.write_bytes(payload_bytes)
        signature_path.write_bytes(signature)
        result = run(
            [
                "openssl",
                "dgst",
                "-sha256",
                "-verify",
                str(public_key_path),
                "-signature",
                str(signature_path),
                str(payload_path),
            ],
            check=False,
            log_output=False,
        )
    if result.returncode != 0:
        raise EntitlementDenied("entitlement lease signature is invalid")
    expected = {
        "unit_id": unit_id(),
        "product_profile": product_profile(),
        "hardware_id": expected_hardware_id,
        "status": "active",
    }
    for key, value in expected.items():
        if str(lease.get(key) or "") != value:
            raise EntitlementDenied(f"entitlement lease {key} does not match this unit")
    try:
        expires_at = parse_utc(str(lease["expires_at"]))
    except Exception as error:
        raise EntitlementDenied("entitlement lease expiry is invalid") from error
    if expires_at <= dt.datetime.now(dt.timezone.utc):
        raise EntitlementDenied("entitlement lease expired")
    return lease


def save_entitlement_lease(response: dict[str, Any]) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    temp_path = ENTITLEMENT_LEASE_PATH.with_suffix(".tmp")
    temp_path.write_text(json.dumps(response, sort_keys=True) + "\n", encoding="utf-8")
    os.chmod(temp_path, 0o600)
    os.replace(temp_path, ENTITLEMENT_LEASE_PATH)


def cached_entitlement_lease(expected_hardware_id: str) -> dict[str, Any]:
    if not ENTITLEMENT_LEASE_PATH.exists():
        raise EntitlementDenied("unit registration is required for updates")
    try:
        response = json.loads(ENTITLEMENT_LEASE_PATH.read_text(encoding="utf-8"))
    except Exception as error:
        raise EntitlementDenied("cached entitlement lease is unreadable") from error
    return verify_entitlement_lease(response, expected_hardware_id)


def refresh_entitlement_lease() -> tuple[dict[str, Any], str, dict[str, Any]]:
    local_unit_id = unit_id()
    if not local_unit_id:
        raise EntitlementDenied("unit_id is not assigned")
    local_hardware_id = hardware_id()
    private_key_path, public_key = ensure_entitlement_device_key()
    payload = {
        "schema": 1,
        "unit_id": local_unit_id,
        "product_profile": product_profile(),
        "hardware_id": local_hardware_id,
        "key_fingerprint": hashlib.sha256(public_key.encode("utf-8")).hexdigest(),
        "timestamp": now_iso(),
        "nonce": secrets.token_hex(16),
    }
    payload_bytes = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    body: dict[str, Any] = {
        "payload": b64url_encode(payload_bytes),
        "signature": b64url_encode(sign_entitlement_payload(payload_bytes, private_key_path)),
        "public_key": public_key,
    }
    if ENTITLEMENT_REGISTRATION_TOKEN_PATH.exists():
        body["registration_token"] = ENTITLEMENT_REGISTRATION_TOKEN_PATH.read_text(encoding="utf-8").strip()
    try:
        response = post_entitlement_request(entitlement_url(), body)
        lease = verify_entitlement_lease(response, local_hardware_id)
        save_entitlement_lease(response)
        if ENTITLEMENT_REGISTRATION_TOKEN_PATH.exists():
            ENTITLEMENT_REGISTRATION_TOKEN_PATH.unlink()
        return lease, "online", response
    except RepositoryUnavailable:
        cached_lease = cached_entitlement_lease(local_hardware_id)
        cached_response = json.loads(ENTITLEMENT_LEASE_PATH.read_text(encoding="utf-8"))
        return cached_lease, "offline-grace", cached_response


def manifest_requires_entitlement(manifest: dict[str, Any]) -> bool:
    return ENTITLEMENT_MARKER_PATH.exists() or ENTITLEMENT_MARKER_PACKAGE_PATH in manifest.get("files", [])


def read_entitled_package(url: str, lease_response: dict[str, Any]) -> bytes:
    body = json.dumps({"lease": lease_response}, separators=(",", ":"), sort_keys=True).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "User-Agent": f"Mozilla/5.0 NodeBlasterUpdater/{VERSION}",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            data = response.read(MAX_DOWNLOAD_BYTES + 1)
    except urllib.error.HTTPError as error:
        if error.code in {400, 401, 403, 404, 409, 422}:
            raise EntitlementDenied(f"entitled package download denied: HTTP {error.code}") from error
        if error.code in {408, 429, 500, 502, 503, 504}:
            raise RepositoryUnavailable(f"Entitled package service unreachable: HTTP {error.code}") from error
        raise
    except (urllib.error.URLError, TimeoutError, socket.timeout, ConnectionError, OSError) as error:
        raise RepositoryUnavailable("Entitled package service unreachable") from error
    if len(data) > MAX_DOWNLOAD_BYTES:
        raise RuntimeError(f"Download exceeded {MAX_DOWNLOAD_BYTES} bytes: {url}")
    return data


def join_url(base_url: str, maybe_relative: str) -> str:
    return urllib.request.urljoin(base_url, maybe_relative)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def configured_manifest_url() -> str:
    env_url = os.environ.get("NODEBLASTER_MANIFEST_URL", "").strip()
    if env_url:
        return env_url
    if MANIFEST_URL_PATH.exists():
        configured = MANIFEST_URL_PATH.read_text(encoding="utf-8").strip()
        if configured:
            return configured
    identity_url = str(unit_identity().get("manifest_url", "")).strip()
    if identity_url:
        return identity_url
    return DEFAULT_MANIFEST_URL


def normalize_product_profile(value: str) -> str:
    normalized = PRODUCT_PROFILE_ALIASES.get(value.strip().lower(), value.strip().lower())
    if not re.fullmatch(r"[a-z0-9-]+", normalized):
        raise RuntimeError(f"Invalid NodeBlaster product profile: {value}")
    return normalized


def unit_identity() -> dict[str, Any]:
    if not IDENTITY_PATH.exists():
        return {}
    try:
        identity = json.loads(IDENTITY_PATH.read_text(encoding="utf-8"))
    except Exception as error:
        raise RuntimeError(f"Could not read NodeBlaster unit identity: {error}") from error
    if not isinstance(identity, dict):
        raise RuntimeError("NodeBlaster unit identity must be a JSON object")
    return identity


def product_profile() -> str:
    env_profile = os.environ.get("NODEBLASTER_PRODUCT_PROFILE", "").strip()
    if env_profile:
        return normalize_product_profile(env_profile)
    if PRODUCT_PROFILE_PATH.exists():
        configured = PRODUCT_PROFILE_PATH.read_text(encoding="utf-8").strip()
        if configured:
            return normalize_product_profile(configured)
    identity_profile = str(unit_identity().get("product_profile", "")).strip()
    if identity_profile:
        return normalize_product_profile(identity_profile)
    return DEFAULT_PRODUCT_PROFILE


def unit_id() -> str:
    env_unit_id = os.environ.get("NODEBLASTER_UNIT_ID", "").strip()
    if env_unit_id:
        return env_unit_id
    return str(unit_identity().get("unit_id", "")).strip()


def current_version() -> str:
    if not CURRENT_VERSION_PATH.exists():
        return "0"
    return CURRENT_VERSION_PATH.read_text(encoding="utf-8").strip() or "0"


def derive_display_version(value: str) -> str:
    value = str(value or "").strip()
    for pattern in (r"stable-bch(\d+)", r"\bbch(\d+)", r"stable(\d+)", r"\bver[.\s-]*(\d+)"):
        match = re.search(pattern, value, re.IGNORECASE)
        if match:
            return f"Ver. {int(match.group(1))}"
    return value or "unknown"


def manifest_display_version(manifest: dict[str, Any]) -> str:
    display = str(manifest.get("display_version") or manifest.get("public_version") or "").strip()
    if display:
        return display
    return derive_display_version(str(manifest.get("version") or ""))


def current_display_version() -> str:
    if CURRENT_DISPLAY_VERSION_PATH.exists():
        display = CURRENT_DISPLAY_VERSION_PATH.read_text(encoding="utf-8").strip()
        if display:
            return display
    return derive_display_version(current_version())


def version_key(value: str) -> tuple[Any, ...]:
    parts: list[Any] = []
    for piece in value.replace("-", ".").split("."):
        for token in re.findall(r"\d+|\D+", piece):
            if token.isdigit():
                parts.append(int(token))
            else:
                parts.append(token)
    return tuple(parts)


def history_entries(limit: int = 20) -> list[dict[str, Any]]:
    if not HISTORY_PATH.exists():
        return []
    entries: list[dict[str, Any]] = []
    for line in HISTORY_PATH.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return entries[-limit:]


def append_history(entry: dict[str, Any]) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with HISTORY_PATH.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, sort_keys=True) + "\n")


def seed_history_if_empty(version: str, manifest: dict[str, Any], manifest_url: str) -> None:
    if HISTORY_PATH.exists() and HISTORY_PATH.stat().st_size > 0:
        return
    append_history(
        {
            "event": "observed-installed",
            "observed_at": now_iso(),
            "version": version,
            "display_version": manifest_display_version(manifest),
            "channel": manifest.get("channel"),
            "product_profile": product_profile(),
            "unit_id": unit_id(),
            "manifest_url": manifest_url,
            "release_notes_url": manifest.get("release_notes_url"),
            "note": "Initial local history seed from current-version marker.",
        }
    )


def write_status(status: dict[str, Any]) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    status = {
        "schema": 1,
        "product": "nodeblaster-umbrel-unit",
        "product_profile": product_profile(),
        "unit_id": unit_id(),
        "updater_version": VERSION,
        "current_version": current_version(),
        "current_display_version": current_display_version(),
        "updated_at": now_iso(),
        **status,
    }
    STATUS_JSON_PATH.write_text(json.dumps(status, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    rows = []
    for entry in reversed(history_entries(limit=12)):
        version = html.escape(str(entry.get("version") or entry.get("installed_version") or "unknown"))
        when = html.escape(str(entry.get("installed_at") or entry.get("observed_at") or ""))
        result = html.escape(str(entry.get("result") or entry.get("event") or ""))
        notes_url = entry.get("release_notes_url")
        if notes_url:
            notes = f'<a href="{html.escape(str(notes_url), quote=True)}">View changes</a>'
        else:
            notes = ""
        rows.append(f"<tr><td>{when}</td><td>{version}</td><td>{result}</td><td>{notes}</td></tr>")

    release_notes_url = status.get("release_notes_url")
    release_link = ""
    if release_notes_url:
        safe_url = html.escape(str(release_notes_url), quote=True)
        release_link = f'<p><a href="{safe_url}">View release notes</a></p>'

    last_error = status.get("error")
    error_html = ""
    if last_error:
        error_html = f'<p class="error">{html.escape(str(last_error))}</p>'

    STATUS_HTML_PATH.write_text(
        """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>NodeBlaster Update Status</title>
  <style>
    body { background:#111; color:#f5f1e8; font:16px/1.45 system-ui,-apple-system,Segoe UI,sans-serif; margin:0; padding:32px; }
    main { max-width:900px; margin:auto; }
    h1 { color:#f8b84e; }
    a { color:#ffcc66; }
    code { background:#222; padding:2px 5px; border-radius:4px; }
    table { width:100%; border-collapse:collapse; margin-top:20px; }
    td, th { border-bottom:1px solid #333; padding:10px; text-align:left; vertical-align:top; }
    .error { color:#ff8b8b; }
  </style>
</head>
<body>
<main>
  <h1>NodeBlaster Update Status</h1>
  <p>Current version: <code>"""
        + html.escape(str(status.get("current_version", "unknown")))
        + """</code></p>
  <p>Last result: <code>"""
        + html.escape(str(status.get("last_result", "unknown")))
        + """</code></p>
  <p>Last check: <code>"""
        + html.escape(str(status.get("last_check_at", status.get("updated_at", ""))))
        + """</code></p>
  """
        + release_link
        + error_html
        + """
  <h2>Version History</h2>
  <table>
    <thead><tr><th>Time</th><th>Version</th><th>Result</th><th>Notes</th></tr></thead>
    <tbody>"""
        + "".join(rows)
        + """</tbody>
  </table>
</main>
</body>
</html>
""",
        encoding="utf-8",
    )


def write_progress(message: str, percent: int, result: str) -> None:
    write_status(
        {
            "last_check_at": now_iso(),
            "last_result": result,
            "progress_message": message,
            "progress_percent": max(0, min(100, int(percent))),
            "progress_updated_at": now_iso(),
            "error": None,
        }
    )


def verify_manifest_signature(manifest_path: Path, signature_path: Path, allow_unsigned_dev: bool) -> None:
    if allow_unsigned_dev:
        log("Unsigned dev manifest allowed by explicit CLI flag")
        return
    if not TRUSTED_KEY_PATH.exists():
        raise RuntimeError(f"Missing trusted release key: {TRUSTED_KEY_PATH}")
    if not shutil.which("openssl"):
        raise RuntimeError("openssl is required for signed manifest verification")
    run(
        [
            "openssl",
            "dgst",
            "-sha256",
            "-verify",
            str(TRUSTED_KEY_PATH),
            "-signature",
            str(signature_path),
            str(manifest_path),
        ],
        check=True,
    )


def validate_manifest(manifest: dict[str, Any]) -> None:
    required = ("version", "channel", "package_url", "sha256", "files")
    missing = [key for key in required if key not in manifest]
    if missing:
        raise RuntimeError(f"Manifest missing required keys: {', '.join(missing)}")
    target_profiles = manifest.get("target_profiles")
    if target_profiles is not None:
        if not isinstance(target_profiles, list) or not all(isinstance(profile, str) for profile in target_profiles):
            raise RuntimeError("Manifest target_profiles must be a list of profile names")
    target_unit_ids = manifest.get("target_unit_ids")
    if target_unit_ids is not None:
        if not isinstance(target_unit_ids, list) or not all(isinstance(target_id, str) for target_id in target_unit_ids):
            raise RuntimeError("Manifest target_unit_ids must be a list of unit IDs")
    for relative_path in manifest["files"]:
        if relative_path not in ALLOWED_FILES:
            raise RuntimeError(f"Manifest includes unsupported target path: {relative_path}")


def manifest_incompatibility_reason(manifest: dict[str, Any]) -> str | None:
    target_profiles = manifest.get("target_profiles")
    if target_profiles:
        profile = product_profile()
        normalized = {str(item).strip().lower() for item in target_profiles}
        if profile not in normalized:
            return f"incompatible product profile: local={profile} target={target_profiles}"

    target_unit_ids = manifest.get("target_unit_ids")
    if target_unit_ids:
        local_unit_id = unit_id()
        if not local_unit_id:
            return f"manifest targets unit IDs but this unit has no unit_id: target={target_unit_ids}"
        normalized_units = {str(item).strip().lower() for item in target_unit_ids}
        if local_unit_id.lower() not in normalized_units:
            return f"incompatible unit ID: local={local_unit_id} target={target_unit_ids}"
    return None


def safe_extract_package(package_path: Path, destination: Path) -> None:
    with tarfile.open(package_path, "r:gz") as archive:
        for member in archive.getmembers():
            if member.islnk() or member.issym():
                raise RuntimeError(f"Package symlinks are not allowed: {member.name}")
            normalized = Path(member.name)
            if normalized.is_absolute() or ".." in normalized.parts:
                raise RuntimeError(f"Unsafe package path: {member.name}")
            if member.isfile() and member.name not in ALLOWED_FILES:
                raise RuntimeError(f"Unexpected package file: {member.name}")
        for member in archive.getmembers():
            if not member.isfile():
                continue
            target = destination / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            source = archive.extractfile(member)
            if source is None:
                raise RuntimeError(f"Could not extract package file: {member.name}")
            with source, target.open("wb") as handle:
                shutil.copyfileobj(source, handle)


def install_files(staging_dir: Path, files: list[str]) -> None:
    backups_dir = STATE_DIR / "backups" / dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    backups_dir.mkdir(parents=True, exist_ok=True)

    for relative_path in files:
        rule = ALLOWED_FILES[relative_path]
        source = staging_dir / relative_path
        target = rule["target"]
        if not source.is_file():
            raise RuntimeError(f"Package file missing after extract: {relative_path}")
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            backup = backups_dir / relative_path
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, backup)
        tmp_target = target.with_name(f".{target.name}.nodeblaster-update")
        shutil.copy2(source, tmp_target)
        os.chmod(tmp_target, rule["mode"])
        os.replace(tmp_target, target)
        log(f"Installed {relative_path} -> {target}")


def write_if_changed(path: Path, content: str, *, mode: int) -> bool:
    normalized = content.rstrip() + "\n"
    if path.exists() and path.read_text(encoding="utf-8") == normalized:
        return False
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp_target = path.with_name(f".{path.name}.nodeblaster-repair")
    tmp_target.write_text(normalized, encoding="utf-8")
    os.chmod(tmp_target, mode)
    os.replace(tmp_target, path)
    log(f"Repaired service unit {path}")
    return True


def manifest_includes_display(manifest: dict[str, Any]) -> bool:
    files = manifest.get("files", [])
    return isinstance(files, list) and any(str(path).startswith(("nodeblaster-display/", "systemd/nodeblaster-display.")) for path in files)


def prepare_control_bridge_runtime(
    app_dir: Path = Path("/home/umbrel/umbrel/app-data/nodeblaster-control"),
    data_dir: Path = Path("/home/umbrel/umbrel/app-data/nodeblaster-control/data"),
    bridge_dir: Path = Path("/home/umbrel/umbrel/app-data/nodeblaster-control/data/host-bridge"),
) -> None:
    for path, uid, gid, mode in (
        (app_dir, 1000, 1000, 0o755),
        (data_dir, 1000, 1000, 0o770),
        (bridge_dir, 0, 1000, 0o770),
    ):
        path.mkdir(parents=True, exist_ok=True)
        os.chown(path, uid, gid)
        os.chmod(path, mode)


def ensure_systemd_units(*, enable_updater_timer: bool, manage_display: bool = False) -> None:
    if not shutil.which("systemctl"):
        log("systemctl not found; skipping systemd unit repair")
        return

    changed = False
    for path, content in SYSTEMD_UNITS.items():
        changed |= write_if_changed(path, content, mode=0o644)
    if changed:
        run(["systemctl", "daemon-reload"], check=True)

    run(["systemctl", "enable", "nodeblaster-branding.service", "nodeblaster-branding.timer"], check=True)
    run(["systemctl", "restart", "nodeblaster-branding.timer"], check=True)

    if enable_updater_timer:
        run(["systemctl", "enable", "nodeblaster-updater.service", "nodeblaster-updater.timer"], check=True)
        run(["systemctl", "restart", "nodeblaster-updater.timer"], check=True)
    else:
        log("Unsigned dev update: leaving nodeblaster-updater.timer disabled until signing is configured")

    status_source = Path("/home/umbrel/umbrel/nodeblaster-status/status_server.py")
    if status_source.exists():
        run(["systemctl", "enable", "nodeblaster-status.service"], check=True)
        run(["systemctl", "restart", "nodeblaster-status.service"], check=True)
    else:
        log(f"Status service source is missing: {status_source}")

    bridge_source = Path("/home/umbrel/umbrel/nodeblaster-control-bridge/bridge.py")
    if bridge_source.exists():
        prepare_control_bridge_runtime()
        run(["systemctl", "enable", "nodeblaster-control-bridge.service"], check=True)
        run(["systemctl", "restart", "nodeblaster-control-bridge.service"], check=True)
    else:
        log(f"Control bridge source is missing: {bridge_source}")

    support_source = Path("/home/umbrel/umbrel/nodeblaster-support/support_access.py")
    if support_source.exists():
        run(["systemctl", "enable", "nodeblaster-support-expire.timer"], check=True)
        run(["systemctl", "restart", "nodeblaster-support-expire.timer"], check=True)
    else:
        log(f"Support access source is missing: {support_source}")

    firewall_source = Path("/home/umbrel/umbrel/nodeblaster-security/apply-hashwatcher-firewall.sh")
    configured_sources = []
    if HASHWATCHER_ALLOW_PATH.is_file():
        configured_sources = [
            line.split("#", 1)[0].strip()
            for line in HASHWATCHER_ALLOW_PATH.read_text(encoding="utf-8").splitlines()
            if line.split("#", 1)[0].strip()
        ]
    if firewall_source.exists() and configured_sources:
        os.chmod(HASHWATCHER_ALLOW_PATH, 0o600)
        run(["systemctl", "start", "nodeblaster-hashwatcher-firewall.service"], check=True)
        run(["systemctl", "enable", "--now", "nodeblaster-hashwatcher-firewall.timer"], check=True)
    else:
        run(["systemctl", "disable", "--now", "nodeblaster-hashwatcher-firewall.timer"], check=False)

    if not manage_display:
        log("Display service policy: preserving current display state")
        return

    display_source = Path("/home/umbrel/umbrel/nodeblaster-display/display.py")
    if display_source.exists():
        display_config = Path("/home/umbrel/umbrel/nodeblaster-display/display-config.json")
        display_style = ""
        if display_config.exists():
            try:
                display_style = str(json.loads(display_config.read_text(encoding="utf-8")).get("style") or "").strip().lower()
            except Exception as error:
                log(f"Could not read display config: {error}")
        if display_style == "console":
            run(["systemctl", "disable", "--now", "nodeblaster-display.service"], check=False)
            log("Display config style=console; nodeblaster-display.service left disabled for root console")
            return
        run(["systemctl", "enable", "nodeblaster-display.service"], check=True)
        run(["systemctl", "restart", "nodeblaster-display.service"], check=False)
        log("Display feature files are present; nodeblaster-display.service enabled and started")
    else:
        log(f"Display feature source is missing: {display_source}")


def apply_branding_full_after_install(*, manage_display: bool = False) -> None:
    agent = Path("/home/umbrel/umbrel/nodeblaster-branding/apply.py")
    if not agent.exists():
        log(f"Branding agent not found after install: {agent}")
        return
    command = [str(agent), "--mode", "full", "--wallpaper-selection", "preserve"]
    if manage_display:
        command += ["--display-policy", "apply"]
    run(command)


def restart_units(*, enable_updater_timer: bool, manage_display: bool = False) -> None:
    ensure_systemd_units(enable_updater_timer=enable_updater_timer, manage_display=manage_display)


def ensure_yaml_list_value(yaml_path: Path, key: str, value: str) -> None:
    if not shutil.which("yq"):
        raise RuntimeError("yq is required to update Umbrel app metadata")
    existing = run(["yq", "e", f".{key}[]", str(yaml_path)], log_output=False)
    if value not in existing.stdout.splitlines():
        run(["yq", "e", "-i", f'.{key} += ["{value}"]', str(yaml_path)], check=True)


def yaml_list_contains(yaml_path: Path, key: str, value: str) -> bool:
    if not shutil.which("yq"):
        raise RuntimeError("yq is required to read Umbrel app metadata")
    existing = run(["yq", "e", f".{key}[]", str(yaml_path)], log_output=False)
    return value in existing.stdout.splitlines()


def enable_blockchair_bch_mempool_app() -> None:
    app_id = "nodeblaster-blockchair-bch-mempool"
    store_url = "https://github.com/cnmne/nodeblaster-umbrel-community-store"
    store_dir_name = "cnmne-nodeblaster-umbrel-community-store-github-d10fbcab"
    umbrel_root = Path("/home/umbrel/umbrel")
    source_store = umbrel_root / "nodeblaster-community-store"
    app_store = umbrel_root / "app-stores" / store_dir_name
    app_data = umbrel_root / "app-data" / app_id
    umbrel_yaml = umbrel_root / "umbrel.yaml"

    if not source_store.exists():
        raise RuntimeError(f"Missing packaged NodeBlaster community store: {source_store}")

    if app_store.exists():
        shutil.rmtree(app_store)
    shutil.copytree(source_store, app_store)
    shutil.chown(app_store, user="umbrel", group="umbrel")
    for path in app_store.rglob("*"):
        shutil.chown(path, user="umbrel", group="umbrel")

    if app_data.exists():
        shutil.rmtree(app_data)
    shutil.copytree(source_store / app_id, app_data)
    shutil.chown(app_data, user="umbrel", group="umbrel")
    for path in app_data.rglob("*"):
        shutil.chown(path, user="umbrel", group="umbrel")

    backup = umbrel_yaml.with_name(f"umbrel.yaml.pre-{app_id}-{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d%H%M%S')}")
    shutil.copy2(umbrel_yaml, backup)
    run(["yq", "e", "-i", '.apps = (.apps | map(select(. != "")))', str(umbrel_yaml)], check=True)
    run(["yq", "e", "-i", '.appRepositories = (.appRepositories | map(select(. != "")))', str(umbrel_yaml)], check=True)
    ensure_yaml_list_value(umbrel_yaml, "apps", app_id)
    ensure_yaml_list_value(umbrel_yaml, "appRepositories", store_url)

    if shutil.which("systemctl"):
        run(["systemctl", "restart", "umbrel.service"])
    log(f"Enabled Umbrel app shortcut {app_id}")


def find_umbrel_app_repo_dir(app_id: str) -> Path:
    umbrel_root = Path("/home/umbrel/umbrel")
    candidates = sorted((umbrel_root / "app-stores").glob(f"*/{app_id}/umbrel-app.yml"))
    if not candidates:
        raise RuntimeError(f"Could not find Umbrel app template for {app_id}")
    return candidates[0].parent


def run_umbrel_app_script(command: str, app_id: str, app_repo_dir: Path) -> None:
    app_script = Path("/opt/umbreld/source/modules/apps/legacy-compat/app-script")
    if not app_script.exists():
        raise RuntimeError(f"Missing Umbrel legacy app script: {app_script}")
    env = {
        **os.environ,
        "SCRIPT_UMBREL_ROOT": "/home/umbrel/umbrel",
        "SCRIPT_APP_REPO_DIR": str(app_repo_dir),
        "SCRIPT_DOCKER_FRAGMENTS": "/opt/umbreld/source/modules/apps/legacy-compat",
        "SCRIPT_APP_DATA_ROOTS": json.dumps(
            {app_id: f"/home/umbrel/umbrel/app-data/{app_id}/data"}
        ),
        "REMOTE_TOR_ACCESS": "false",
    }
    result = subprocess.run(
        [str(app_script), command, app_id],
        text=True,
        capture_output=True,
        env=env,
    )
    if result.stdout.strip():
        log(f"{app_script.name} stdout: {result.stdout.strip()}")
    if result.stderr.strip():
        log(f"{app_script.name} stderr: {result.stderr.strip()}")
    if result.returncode != 0:
        raise RuntimeError(f"Umbrel app {command} failed for {app_id} with {result.returncode}")


def refresh_umbreld_app_registry() -> None:
    if shutil.which("systemctl"):
        run(["systemctl", "restart", "umbrel.service"], check=True)


def widget_payload_fingerprint(source: Path, required: tuple[str, ...]) -> str:
    digest = hashlib.sha256()
    for name in sorted(required):
        digest.update(name.encode("utf-8"))
        digest.update(b"\0")
        digest.update((source / name).read_bytes())
    return digest.hexdigest()


def install_nodeblaster_miner_widget() -> None:
    app_id = "nodeblaster-miner-widget"
    umbrel_root = Path("/home/umbrel/umbrel")
    source = umbrel_root / "nodeblaster-updater" / "apps" / app_id
    app_store_root = umbrel_root / "app-stores" / "nodeblaster-private"
    app_store = app_store_root / app_id
    app_data = umbrel_root / "app-data" / app_id
    widget_state_path = app_data / "data" / "miner-widget-state.json"
    widget_state = widget_state_path.read_bytes() if widget_state_path.is_file() else None
    payload_marker = app_data / ".nodeblaster-payload-sha256"
    umbrel_yaml = umbrel_root / "umbrel.yaml"
    required = ("umbrel-app.yml", "docker-compose.yml", "nginx.conf", "nodeblaster-miner-widget-icon.png")
    missing = [name for name in required if not (source / name).is_file()]
    if missing:
        raise RuntimeError(f"Missing packaged NodeBlaster widget files: {', '.join(missing)}")
    payload_fingerprint = widget_payload_fingerprint(source, required)
    registered = yaml_list_contains(umbrel_yaml, "apps", app_id)
    if registered and payload_marker.is_file():
        if payload_marker.read_text(encoding="utf-8").strip() == payload_fingerprint:
            log(f"NodeBlaster widget {app_id} is already installed from this payload")
            return

    if app_store.exists():
        shutil.rmtree(app_store)
    app_store_root.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source, app_store)
    (app_store_root / "umbrel-app-store.yml").write_text(
        "id: nodeblaster-private\nname: NodeBlaster\n", encoding="utf-8"
    )

    if app_data.exists():
        shutil.rmtree(app_data)
    shutil.copytree(source, app_data)
    if widget_state is not None:
        widget_state_path.parent.mkdir(parents=True, exist_ok=True)
        widget_state_path.write_bytes(widget_state)
    payload_marker.write_text(payload_fingerprint + "\n", encoding="utf-8")
    for tree in (app_store_root, app_data):
        shutil.chown(tree, user="umbrel", group="umbrel")
        for path in tree.rglob("*"):
            shutil.chown(path, user="umbrel", group="umbrel")

    ui_icon = Path("/opt/umbreld/ui/assets/nodeblaster-miner-widget-icon.png")
    shutil.copy2(source / "nodeblaster-miner-widget-icon.png", ui_icon)
    os.chown(ui_icon, 0, 0)
    os.chmod(ui_icon, 0o644)

    backup = umbrel_yaml.with_name(
        f"umbrel.yaml.pre-{app_id}-{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d%H%M%S')}"
    )
    shutil.copy2(umbrel_yaml, backup)
    run(["yq", "e", "-i", '.apps = (.apps | map(select(. != "")))', str(umbrel_yaml)], check=True)
    ensure_yaml_list_value(umbrel_yaml, "apps", app_id)
    run_umbrel_app_script("restart" if registered else "install", app_id, app_store)
    if not registered:
        refresh_umbreld_app_registry()
    log(f"Installed private Umbrel app {app_id} from updater payload")


def restart_umbrel_app(app_id: str) -> None:
    run_umbrel_app_script("restart", app_id, find_umbrel_app_repo_dir(app_id))


def set_bithunter_mempool_heap_limit() -> None:
    profile = product_profile()
    if profile != "bithunter":
        log(f"Skipping Bithunter Mempool heap fix for product profile {profile}")
        return

    compose_path = Path("/home/umbrel/umbrel/app-data/mempool/docker-compose.yml")
    if not compose_path.exists():
        log("Skipping Bithunter Mempool heap fix because native Mempool is not installed")
        return

    text = compose_path.read_text(encoding="utf-8")
    updated = text
    if "max-old-space-size=8192" not in updated:
        updated = re.sub(r"max-old-space-size=\d+", "max-old-space-size=8192", updated, count=1)
        if updated == text:
            marker = "      MEMPOOL_STDOUT_LOG_MIN_PRIORITY: info\n"
            if marker not in updated:
                raise RuntimeError("Could not find a safe insertion point for Mempool NODE_OPTIONS")
            updated = updated.replace(marker, marker + "      NODE_OPTIONS: '--max-old-space-size=8192'\n", 1)

        backup = compose_path.with_name(
            f"docker-compose.yml.pre-bithunter-mempool-heap-{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d%H%M%S')}"
        )
        shutil.copy2(compose_path, backup)
        compose_path.write_text(updated, encoding="utf-8")
        log(f"Set Bithunter native Mempool backend heap limit to 8192 MB; backup={backup}")
    else:
        log("Bithunter native Mempool backend heap limit is already 8192 MB")

    restart_umbrel_app("mempool")
    log("Restarted native Mempool after Bithunter heap configuration")


def configure_nodeblaster_dual_audio() -> None:
    if not shutil.which("aplay"):
        if not shutil.which("apt-get"):
            raise RuntimeError("apt-get is required to install alsa-utils")
        run(["apt-get", "update", "-qq"], check=True)
        run(
            ["apt-get", "install", "-y", "alsa-utils"],
            check=True,
            env={**os.environ, "DEBIAN_FRONTEND": "noninteractive"},
        )
    if not shutil.which("amixer") or not shutil.which("alsactl"):
        raise RuntimeError("alsa-utils did not provide the expected mixer tools")
    result = run(["amixer", "-c", "0", "sset", "Master", "80%", "unmute"], check=False)
    if result.returncode == 0:
        run(["alsactl", "store", "0"], check=True)
        log("Configured analog Master at 80%, unmuted, and saved ALSA state")
    else:
        log("Analog Master control is unavailable; leaving mixer state unchanged")


def install_nodeblaster_hashwatcher_firewall() -> None:
    if not shutil.which("systemctl"):
        log("systemctl not found; skipping HashWatcher firewall activation")
        return

    configured_sources = []
    if HASHWATCHER_ALLOW_PATH.is_file():
        configured_sources = [
            line.split("#", 1)[0].strip()
            for line in HASHWATCHER_ALLOW_PATH.read_text(encoding="utf-8").splitlines()
            if line.split("#", 1)[0].strip()
        ]
    if not configured_sources:
        run(["systemctl", "disable", "--now", "nodeblaster-hashwatcher-firewall.timer"], check=False)
        log("HashWatcher firewall installed but left disabled: no per-unit allow-list configured")
        return

    os.chmod(HASHWATCHER_ALLOW_PATH, 0o600)
    run(["systemctl", "daemon-reload"], check=True)
    run(["systemctl", "start", "nodeblaster-hashwatcher-firewall.service"], check=True)
    run(["systemctl", "enable", "--now", "nodeblaster-hashwatcher-firewall.timer"], check=True)
    log("HashWatcher firewall enabled from the local per-unit allow-list")


POST_INSTALL_ACTIONS = {
    "enable_blockchair_bch_mempool_app": enable_blockchair_bch_mempool_app,
    "install_nodeblaster_miner_widget": install_nodeblaster_miner_widget,
    "set_bithunter_mempool_heap_limit": set_bithunter_mempool_heap_limit,
    "configure_nodeblaster_dual_audio": configure_nodeblaster_dual_audio,
    "install_nodeblaster_hashwatcher_firewall": install_nodeblaster_hashwatcher_firewall,
}


def run_post_install_actions(manifest: dict[str, Any]) -> None:
    actions = manifest.get("post_install_actions", [])
    if not actions:
        return
    if not isinstance(actions, list) or not all(isinstance(action, str) for action in actions):
        raise RuntimeError("Manifest post_install_actions must be a list of action names")
    for action in actions:
        handler = POST_INSTALL_ACTIONS.get(action)
        if handler is None:
            raise RuntimeError(f"Unsupported post-install action: {action}")
        log(f"Running post-install action: {action}")
        handler()


def update_once(manifest_url: str, allow_unsigned_dev: bool) -> int:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="nodeblaster-update-") as tmp:
        tmp_dir = Path(tmp)
        manifest_path = tmp_dir / "manifest.json"
        signature_path = tmp_dir / "manifest.json.sig"
        write_progress("Checking update manifest", 10, "checking-manifest")
        manifest_bytes = read_url(manifest_url)
        manifest_path.write_bytes(manifest_bytes)
        manifest = json.loads(manifest_bytes.decode("utf-8-sig"))
        validate_manifest(manifest)
        profile = product_profile()
        local_unit_id = unit_id()
        entitlement_required = manifest_requires_entitlement(manifest)
        entitlement_response: dict[str, Any] | None = None

        incompatible = manifest_incompatibility_reason(manifest)
        if incompatible:
            log(f"Skipping manifest for incompatible target: {incompatible}")
            write_status(
                {
                    "last_check_at": now_iso(),
                    "last_result": "skipped-incompatible-target",
                    "available_version": manifest.get("version"),
                    "available_display_version": manifest_display_version(manifest),
                    "manifest_url": manifest_url,
                    "target_profiles": manifest.get("target_profiles"),
                    "target_unit_ids": manifest.get("target_unit_ids"),
                    "skip_reason": incompatible,
                    "progress_message": "Update skipped for this unit profile",
                    "progress_percent": 100,
                    "progress_updated_at": now_iso(),
                }
            )
            return 0

        write_progress("Verifying signed manifest", 25, "verifying-manifest")
        if not allow_unsigned_dev:
            sig_url = join_url(manifest_url, manifest.get("signature_url", "manifest.json.sig"))
            signature_path.write_bytes(read_url(sig_url, max_bytes=1024 * 1024))
        verify_manifest_signature(manifest_path, signature_path, allow_unsigned_dev)

        if not allow_unsigned_dev and entitlement_required:
            write_progress("Validating unit registration", 30, "checking-entitlement")
            lease, lease_source, entitlement_response = refresh_entitlement_lease()
            write_status(
                {
                    "last_check_at": now_iso(),
                    "last_result": "entitlement-validated",
                    "entitlement_status": lease.get("status"),
                    "entitlement_expires_at": lease.get("expires_at"),
                    "entitlement_source": lease_source,
                    "progress_message": "Unit registration validated",
                    "progress_percent": 32,
                    "progress_updated_at": now_iso(),
                }
            )

        write_progress("Comparing installed and available versions", 35, "checking-version")
        available = str(manifest["version"])
        available_display = manifest_display_version(manifest)
        installed = current_version()
        release_notes_url = manifest.get("release_notes_url")
        seed_history_if_empty(installed, manifest, manifest_url)

        if available == installed:
            log(f"No update needed: installed={installed} available={available}")
            CURRENT_DISPLAY_VERSION_PATH.write_text(available_display + "\n", encoding="utf-8")
            write_progress("Checking for updates", 70, "repairing-services")
            ensure_systemd_units(enable_updater_timer=not allow_unsigned_dev)
            write_status(
                {
                    "last_check_at": now_iso(),
                    "last_result": "no-update-needed",
                    "available_version": available,
                    "available_display_version": available_display,
                    "display_version": available_display,
                    "target_profiles": manifest.get("target_profiles"),
                    "target_unit_ids": manifest.get("target_unit_ids"),
                    "release_notes_url": release_notes_url,
                    "manifest_url": manifest_url,
                    "progress_message": "Already up to date",
                    "progress_percent": 100,
                    "progress_updated_at": now_iso(),
                }
            )
            return 0

        if version_key(available) <= version_key(installed) and not manifest.get("allow_reinstall", False):
            log(f"No update needed: installed={installed} available={available}")
            CURRENT_DISPLAY_VERSION_PATH.write_text(available_display + "\n", encoding="utf-8")
            write_progress("Checking for updates", 70, "repairing-services")
            ensure_systemd_units(enable_updater_timer=not allow_unsigned_dev)
            write_status(
                {
                    "last_check_at": now_iso(),
                    "last_result": "no-update-needed",
                    "available_version": available,
                    "available_display_version": available_display,
                    "display_version": available_display,
                    "target_profiles": manifest.get("target_profiles"),
                    "target_unit_ids": manifest.get("target_unit_ids"),
                    "release_notes_url": release_notes_url,
                    "manifest_url": manifest_url,
                    "progress_message": "Already up to date",
                    "progress_percent": 100,
                    "progress_updated_at": now_iso(),
                }
            )
            return 0

        package_url = join_url(manifest_url, str(manifest["package_url"]))
        write_progress(f"Downloading update package {available}", 45, "downloading-package")
        if entitlement_required:
            parsed_package_url = urllib.parse.urlparse(package_url)
            if (
                parsed_package_url.scheme != "https"
                or parsed_package_url.hostname != "nodeblaster.com"
                or parsed_package_url.path != "/updates/umbrel-nodeblaster/entitlement/package.php"
            ):
                raise EntitlementDenied("enforced release does not use the entitlement package gateway")
            if entitlement_response is None:
                raise EntitlementDenied("signed entitlement lease is unavailable")
            package_bytes = read_entitled_package(package_url, entitlement_response)
        else:
            package_bytes = read_url(package_url)
        write_progress("Verifying package SHA256", 60, "verifying-package")
        package_sha = sha256_bytes(package_bytes)
        expected_sha = str(manifest["sha256"]).lower()
        if package_sha.lower() != expected_sha:
            raise RuntimeError(f"Package SHA256 mismatch: got {package_sha}, expected {expected_sha}")
        package_path = tmp_dir / "package.tar.gz"
        package_path.write_bytes(package_bytes)

        staging_dir = tmp_dir / "staging"
        staging_dir.mkdir()
        safe_extract_package(package_path, staging_dir)
        write_progress(f"Installing update {available}", 72, "installing")
        install_files(staging_dir, list(manifest["files"]))
        write_progress("Running post-install actions", 82, "running-post-install")
        run_post_install_actions(manifest)
        write_progress("Applying latest update", 88, "applying-branding")
        manage_display = manifest_includes_display(manifest)
        apply_branding_full_after_install(manage_display=manage_display)
        write_progress("Restarting NodeBlaster services", 94, "restarting-services")
        restart_units(enable_updater_timer=not allow_unsigned_dev, manage_display=manage_display)
        CURRENT_VERSION_PATH.write_text(available + "\n", encoding="utf-8")
        CURRENT_DISPLAY_VERSION_PATH.write_text(available_display + "\n", encoding="utf-8")
        append_history(
            {
                "event": "installed",
                "installed_at": now_iso(),
                "previous_version": installed,
                "version": available,
                "display_version": available_display,
                "channel": manifest.get("channel"),
                "product_profile": profile,
                "unit_id": local_unit_id,
                "target_profiles": manifest.get("target_profiles"),
                "target_unit_ids": manifest.get("target_unit_ids"),
                "manifest_url": manifest_url,
                "package_url": package_url,
                "package_sha256": package_sha,
                "release_notes_url": release_notes_url,
                "files": list(manifest["files"]),
                "result": "installed",
            }
        )
        write_status(
            {
                "last_check_at": now_iso(),
                "last_result": "installed",
                "previous_version": installed,
                "available_version": available,
                "available_display_version": available_display,
                "display_version": available_display,
                "target_profiles": manifest.get("target_profiles"),
                "target_unit_ids": manifest.get("target_unit_ids"),
                "release_notes_url": release_notes_url,
                "manifest_url": manifest_url,
                "package_sha256": package_sha,
                "progress_message": f"Installed {available_display}",
                "progress_percent": 100,
                "progress_updated_at": now_iso(),
            }
        )
        log(f"Installed NodeBlaster update {available}")
        return 0


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Check and install signed NodeBlaster unit updates.")
    parser.add_argument("--manifest-url")
    parser.add_argument("--product-profile", help="Override the local product profile for this run.")
    parser.add_argument(
        "--install-nodeblaster-widget",
        action="store_true",
        help="Install the private NodeBlaster miner widget from the updater-owned payload.",
    )
    parser.add_argument(
        "--allow-unsigned-dev",
        action="store_true",
        help="For local dev testing only. Production timers must not use this flag.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.product_profile:
        os.environ["NODEBLASTER_PRODUCT_PROFILE"] = args.product_profile
    if os.geteuid() != 0:
        log("NodeBlaster updater must run as root")
        return 1
    lock_handle = acquire_lock()
    if lock_handle is None:
        return 0
    try:
        if args.install_nodeblaster_widget:
            install_nodeblaster_miner_widget()
            return 0
        reason = update_activity_reason()
        if reason:
            log(f"Umbrel or OS update activity detected; skipping NodeBlaster updater: {reason}")
            write_status(
                {
                    "last_check_at": now_iso(),
                    "last_result": "skipped-update-activity",
                    "error": reason,
                    "progress_message": "Skipped because Umbrel or OS update activity is active",
                    "progress_percent": 100,
                    "progress_updated_at": now_iso(),
                }
            )
            return 0
        return update_once(args.manifest_url or configured_manifest_url(), args.allow_unsigned_dev)
    except RepositoryUnavailable as error:
        log(f"{error}; reporting no update needed")
        write_status(
            {
                "last_check_at": now_iso(),
                "last_result": "no-update-needed",
                "error": None,
                "progress_message": "Your NodeBlaster is up to date",
                "progress_percent": 100,
                "progress_updated_at": now_iso(),
            }
        )
        return 0
    except EntitlementDenied as error:
        log(f"Update blocked by unit entitlement: {error}")
        write_status(
            {
                "last_check_at": now_iso(),
                "last_result": "blocked-entitlement",
                "entitlement_status": "denied",
                "error": str(error),
                "progress_message": "Update blocked: unit registration required",
                "progress_percent": 100,
                "progress_updated_at": now_iso(),
            }
        )
        return 0
    except Exception as error:
        log(f"Updater failed: {error}")
        write_status(
            {
                "last_check_at": now_iso(),
                "last_result": "failed",
                "error": str(error),
                "progress_message": "Update check failed",
                "progress_percent": 100,
                "progress_updated_at": now_iso(),
            }
        )
        return 1
    finally:
        fcntl.flock(lock_handle, fcntl.LOCK_UN)
        lock_handle.close()


if __name__ == "__main__":
    raise SystemExit(main())


