#!/usr/bin/env bash
set -euo pipefail

IPTABLES="${IPTABLES:-/usr/sbin/iptables}"
IP6TABLES="${IP6TABLES:-/usr/sbin/ip6tables}"
PYTHON="${PYTHON:-/usr/bin/python3}"
ALLOW_FILE="${ALLOW_FILE:-/home/umbrel/umbrel/nodeblaster-security/hashwatcher-firewall.allow}"
IPV4_CHAIN="NODEBLASTER-HASHWATCHER"
IPV6_CHAIN="NODEBLASTER-HW6"
PORT="8787"

remove_jump() {
    local tool="$1"
    local chain="$2"
    while "$tool" -w 10 -C DOCKER-USER -p tcp --dport "$PORT" -j "$chain" 2>/dev/null; do
        "$tool" -w 10 -D DOCKER-USER -p tcp --dport "$PORT" -j "$chain"
    done
}

remove_rules() {
    if "$IPTABLES" -w 10 -S DOCKER-USER >/dev/null 2>&1; then
        remove_jump "$IPTABLES" "$IPV4_CHAIN"
        "$IPTABLES" -w 10 -F "$IPV4_CHAIN" 2>/dev/null || true
        "$IPTABLES" -w 10 -X "$IPV4_CHAIN" 2>/dev/null || true
    fi
    if command -v "$IP6TABLES" >/dev/null 2>&1 && "$IP6TABLES" -w 10 -S DOCKER-USER >/dev/null 2>&1; then
        remove_jump "$IP6TABLES" "$IPV6_CHAIN"
        "$IP6TABLES" -w 10 -F "$IPV6_CHAIN" 2>/dev/null || true
        "$IP6TABLES" -w 10 -X "$IPV6_CHAIN" 2>/dev/null || true
    fi
}

if [[ "${1:-apply}" == "remove" ]]; then
    remove_rules
    exit 0
fi
if [[ ! -r "$ALLOW_FILE" ]]; then
    echo "Missing allow-list: $ALLOW_FILE" >&2
    exit 1
fi

mapfile -t ALLOWED_IPV4 < <(
    "$PYTHON" - "$ALLOW_FILE" <<'PY'
import ipaddress
import pathlib
import sys

path = pathlib.Path(sys.argv[1])
for raw in path.read_text(encoding="utf-8").splitlines():
    value = raw.split("#", 1)[0].strip()
    if not value:
        continue
    network = ipaddress.ip_network(value, strict=False)
    if network.version != 4:
        raise SystemExit(f"IPv4 allow-list entry required: {value}")
    print(network)
PY
)

if [[ "${#ALLOWED_IPV4[@]}" -eq 0 ]]; then
    echo "Allow-list is empty; refusing to lock out management access" >&2
    exit 1
fi

"$IPTABLES" -w 10 -N "$IPV4_CHAIN" 2>/dev/null || true
"$IPTABLES" -w 10 -F "$IPV4_CHAIN"
"$IPTABLES" -w 10 -A "$IPV4_CHAIN" -s 127.0.0.0/8 -j RETURN
"$IPTABLES" -w 10 -A "$IPV4_CHAIN" -s 10.21.0.0/16 -j RETURN
for source in "${ALLOWED_IPV4[@]}"; do
    "$IPTABLES" -w 10 -A "$IPV4_CHAIN" -s "$source" -j RETURN
done
"$IPTABLES" -w 10 -A "$IPV4_CHAIN" -j DROP
remove_jump "$IPTABLES" "$IPV4_CHAIN"
"$IPTABLES" -w 10 -I DOCKER-USER 1 -p tcp --dport "$PORT" -j "$IPV4_CHAIN"

if command -v "$IP6TABLES" >/dev/null 2>&1 && "$IP6TABLES" -w 10 -S DOCKER-USER >/dev/null 2>&1; then
    "$IP6TABLES" -w 10 -N "$IPV6_CHAIN" 2>/dev/null || true
    "$IP6TABLES" -w 10 -F "$IPV6_CHAIN"
    "$IP6TABLES" -w 10 -A "$IPV6_CHAIN" -s ::1/128 -j RETURN
    "$IP6TABLES" -w 10 -A "$IPV6_CHAIN" -j DROP
    remove_jump "$IP6TABLES" "$IPV6_CHAIN"
    "$IP6TABLES" -w 10 -I DOCKER-USER 1 -p tcp --dport "$PORT" -j "$IPV6_CHAIN"
fi
